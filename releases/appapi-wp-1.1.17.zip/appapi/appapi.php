<?php
/*
Plugin Name: 게시판모아 앱 연동 (BoardMoa)
Plugin URI: https://github.com/easyapplabs/boardmoa-wordpress
Description: 스마트폰 앱 게시판모아(BoardMoa)가 이 사이트의 글·페이지와 KBoard·망보드·bbPress 게시판을 쓸 수 있게 합니다. 권한은 워드프레스와 각 게시판 플러그인의 설정을 그대로 따릅니다.
Version: 1.1.17
Requires at least: 6.0
Requires PHP: 7.4
Author: EasyAppLabs
Author URI: https://www.easyapplabs.com/
License: GPLv2 or later
Text Domain: boardmoa
Update URI: https://github.com/easyapplabs/boardmoa-wordpress
*/

/*
 * XE1·Rhymix 모듈(server/appapi)·XE3 플러그인(server/xe3/appapi)과 같은 규약(docs/API.md)으로 응답해서, 앱은 엔진을 구별하지 않는다.
 * 주소: <사이트>/wp-content/plugins/appapi/api.php?r=<route>  (어느 웹 서버·고유주소 설정에서도 되는 실제 파일)
 *       <사이트>/modules/appapi/api.php?r=<route>          (고유주소를 쓰는 Apache 처럼 없는 파일을 워드프레스로 넘기는 서버)
 * 게시판: 워드프레스 글 분류·페이지(항상), KBoard, 망보드, bbPress — 설치된 것만. 권한은 워드프레스 권한(capabilities)과 각 플러그인의 판단 함수를 쓴다.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BOARDMOA_VERSION', '1.1.17');
define('BOARDMOA_DIR', __DIR__);
define('BOARDMOA_FILE', __FILE__);

require_once __DIR__ . '/includes/class-error.php';
require_once __DIR__ . '/includes/class-text.php';
require_once __DIR__ . '/includes/class-store.php';
require_once __DIR__ . '/includes/class-run.php';
require_once __DIR__ . '/includes/class-html.php';
require_once __DIR__ . '/includes/class-gate.php';
require_once __DIR__ . '/includes/class-captcha.php';
require_once __DIR__ . '/includes/class-polls.php';
require_once __DIR__ . '/includes/class-api.php';
require_once __DIR__ . '/includes/class-boards.php';
require_once __DIR__ . '/includes/class-my.php';
require_once __DIR__ . '/includes/class-updater.php';
require_once __DIR__ . '/adapters/class-adapter.php';
require_once __DIR__ . '/adapters/class-core.php';
require_once __DIR__ . '/adapters/class-kboard.php';
require_once __DIR__ . '/adapters/class-bbpress.php';
require_once __DIR__ . '/adapters/class-mangboard.php';

register_activation_hook(__FILE__, ['BoardMoa_Store', 'install']);

BoardMoa_Api::bootstrap();
// 웹에서 로그인을 끊으면 앱 토큰도 (프로필 화면의 '모든 곳에서 로그아웃', 애플리케이션 비밀번호 지우기)
add_action('wp_ajax_destroy-sessions', ['BoardMoa_Api', 'onDestroySessions'], 0);
add_action('wp_delete_application_password', ['BoardMoa_Api', 'onDeleteAppPassword'], 10, 2);

if (is_admin()) {
    require_once __DIR__ . '/includes/class-admin.php';
    BoardMoa_Admin::init();
}
