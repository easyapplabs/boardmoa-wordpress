<?php
/**
 * 게시판모아 앱 연동 — 앱이 부르는 주소 (<사이트>/wp-content/plugins/appapi/api.php?r=<route>).
 * 워드프레스를 불러오면 플러그인(appapi.php)이 요청을 처리하고 끝낸다. 플러그인이 꺼져 있으면 404.
 */
define('BOARDMOA_API_ENTRY', true);

// wp-load.php 찾기: 보통 플러그인 폴더의 세 단계 위. wp-content 를 옮긴 사이트도 있어 위로 올라가며 찾는다
$dir = __DIR__;
$found = null;
for ($i = 0; $i < 8; $i++) {
    $dir = dirname($dir);
    if (is_file($dir . '/wp-load.php')) {
        $found = $dir . '/wp-load.php';
        break;
    }
}
if ($found === null) {
    header('Content-Type: application/json; charset=utf-8', true, 500);
    echo '{"ok":false,"error":{"code":"server_error","message":"wp-load.php not found"}}';
    exit;
}
require $found;

// 여기까지 왔으면 플러그인이 꺼져 있거나 처리하지 않았다
if (!class_exists('BoardMoa_Api')) {
    header('Content-Type: application/json; charset=utf-8', true, 404);
    echo '{"ok":false,"error":{"code":"unknown_route","message":"BoardMoa plugin is not active"}}';
    exit;
}
BoardMoa_Api::handle();
