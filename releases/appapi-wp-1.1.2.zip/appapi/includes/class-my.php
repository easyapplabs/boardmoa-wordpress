<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 내 활동·회원 (docs/API.md '내 활동', '내 정보 수정', '회원가입') */
class BoardMoa_My
{
    /** 이 사이트에서 되는 것만 보낸다. 쪽지·친구·알림은 워드프레스에 없고, 스크랩은 bbPress 즐겨찾기를 켠 사이트만 */
    public static function menu()
    {
        $items = [
            ['key' => 'documents', 'title' => BoardMoa_Text::t('내가 쓴 글')],
            ['key' => 'comments', 'title' => BoardMoa_Text::t('내가 쓴 댓글')],
        ];
        if (self::favorites()) {
            $items[] = ['key' => 'scraps', 'title' => BoardMoa_Text::t('스크랩')];
        }
        return ['items' => $items];
    }

    /** bbPress 즐겨찾기 (웹 프로필의 '즐겨찾기'와 같다). 없으면 null */
    private static function favorites()
    {
        $bb = BoardMoa_Boards::adapter('bbpress');
        return ($bb && BoardMoa_BBPress::favoritesOn() && current_user_can('edit_user', get_current_user_id())) ? $bb : null;
    }

    /** 스크랩 = bbPress 즐겨찾기 */
    public static function scraps()
    {
        $bb = self::favorites();
        if (!$bb) {
            throw new BoardMoa_Error(403, 'feature_disabled', '이 사이트에서는 쓸 수 없는 기능입니다.');
        }
        $page = min(10000, max(1, BoardMoa_Api::intParam('page', 1)));
        $count = 20;
        list($docs, $total) = $bb->myScraps($page, $count);
        return ['documents' => $docs, 'folders' => [], 'folder_srl' => null, 'page' => $page,
            'total_pages' => max(1, (int)ceil($total / $count)), 'total_count' => $total];
    }

    public static function scrapDelete()
    {
        $bb = self::favorites();
        if (!$bb) {
            throw new BoardMoa_Error(403, 'feature_disabled', '이 사이트에서는 쓸 수 없는 기능입니다.');
        }
        return $bb->scrapDelete(BoardMoa_Api::intParam('document_srl'));
    }

    /** 내가 쓴 글: 목록을 볼 수 있는 게시판의 내 글 (어댑터마다 모아 최신순) */
    public static function documents()
    {
        $page = min(BoardMoa_Boards::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $count = 20;
        $rows = [];
        foreach (BoardMoa_Boards::adapters() as $adapter) {
            if (method_exists($adapter, 'myDocuments')) {
                $rows = array_merge($rows, $adapter->myDocuments($page * $count + 1));
            }
        }
        usort($rows, function ($a, $b) {
            return $b['time'] <=> $a['time'];
        });
        $total = count($rows);
        $docs = array_map(function ($row) {
            return $row['summary'];
        }, array_slice($rows, ($page - 1) * $count, $count));
        return ['documents' => $docs, 'page' => $page, 'total_pages' => $total > $page * $count ? $page + 1 : $page, 'total_count' => $total];
    }

    public static function comments()
    {
        $page = min(BoardMoa_Boards::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $count = 20;
        $rows = [];
        foreach (BoardMoa_Boards::adapters() as $adapter) {
            if (method_exists($adapter, 'myComments')) {
                $rows = array_merge($rows, $adapter->myComments($page * $count + 1));
            }
        }
        usort($rows, function ($a, $b) {
            return $b['time'] <=> $a['time'];
        });
        $total = count($rows);
        $items = array_map(function ($row) {
            return $row['comment'];
        }, array_slice($rows, ($page - 1) * $count, $count));
        return ['comments' => $items, 'page' => $page, 'total_pages' => $total > $page * $count ? $page + 1 : $page, 'total_count' => $total];
    }

    /** 이름 메뉴의 회원: 이 사이트의 회원만 (멀티사이트는 이 사이트에 속한 회원) */
    private static function target()
    {
        $id = BoardMoa_Api::intParam('member_srl');
        $user = $id > 0 ? get_userdata($id) : null;
        if (!$user || (is_multisite() && !is_user_member_of_blog($user->ID))) {
            return null;
        }
        return $user;
    }

    /**
     * 남의 회원 정보를 볼 수 있는가: 로그인한 회원만. 관리자(list_users)·본인은 늘, 남은 웹의 글쓴이 보관함(/author/…)처럼
     * 공개한 글·토픽·답글(또는 KBoard 글, 승인된 댓글)이 있는 회원만 — 아무 번호나 넣어 회원을 훑지 못하게
     */
    private static function canInfo($user)
    {
        if (!$user || !is_user_logged_in()) {
            return false;
        }
        if ((int)$user->ID === get_current_user_id() || current_user_can('list_users')) {
            return true;
        }
        return self::hasPublicContent((int)$user->ID);
    }

    private static function hasPublicContent($userId)
    {
        global $wpdb;
        $types = array_values(get_post_types(['public' => true]));
        $statuses = ['publish'];
        if (function_exists('bbp_get_topic_post_type')) {
            $types[] = bbp_get_topic_post_type();
            $types[] = bbp_get_reply_post_type();
            $statuses[] = bbp_get_closed_status_id();
        }
        $types = array_unique(array_diff($types, ['attachment']));
        $in = implode(',', array_fill(0, count($types), '%s'));
        $st = implode(',', array_fill(0, count($statuses), '%s'));
        if ($wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$wpdb->posts} WHERE post_author = %d AND post_type IN ($in) AND post_status IN ($st) AND post_password = '' LIMIT 1", array_merge([$userId], $types, $statuses)))) {
            return true;
        }
        if ($wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$wpdb->comments} WHERE user_id = %d AND comment_approved = '1' LIMIT 1", $userId))) {
            return true;
        }
        if (BoardMoa_Boards::adapter('kboard')) {
            return (bool)$wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$wpdb->prefix}kboard_board_content WHERE member_uid = %d AND (status IS NULL OR status = '') LIMIT 1", $userId));
        }
        return false;
    }

    /**
     * 이름 메뉴: '작성 글 보기'(그 게시판에서 그 회원의 글 — 어댑터가 member_srl 로 거른다, 웹의 글쓴이 보관함·게시판 글쓴이 검색과 같은 목록)와
     * '회원 정보'(볼 수 있을 때). 워드프레스에는 쪽지·친구가 없다.
     * 작성 글 보기는 회원이 있는지와 상관없이 같은 모양이다(없는 회원이면 빈 목록): 비회원이 번호를 넣어 회원이 있는지 알아내지 못하게
     */
    public static function memberMenu()
    {
        $id = BoardMoa_Api::intParam('member_srl');
        $actions = [];
        // 새 앱(web=1, 1.0.35~): 웹에서 그 이름을 눌렀을 때와 같은 메뉴. 예전 앱은 아래 예전 메뉴를 그대로 받는다
        if ($id > 0 && (string)BoardMoa_Api::param('web', '') === '1') {
            $mid = (string)BoardMoa_Api::param('mid', '');
            $board = $mid !== '' && preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $mid) ? BoardMoa_Boards::get($mid) : null;
            if ($board && $board['module'] === 'board') {
                $actions = BoardMoa_Boards::adapterOf($board)->webNameMenu($board, $id);
            }
            return ['member_srl' => $id, 'actions' => $actions];
        }
        if ($id > 0) {
            $mid = (string)BoardMoa_Api::param('mid', '');
            $board = $mid !== '' && preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $mid) ? BoardMoa_Boards::get($mid) : null;
            // 워드프레스 글: 웹의 글쓴이 보관함(/author/<이름>/)처럼 분류와 상관없이 글 전체에서 (1.0.34~)
            if ($board && $board['adapter'] === 'core' && $board['module'] === 'board' && $board['mid'] !== 'posts') {
                $board = BoardMoa_Boards::get('posts');
            }
            if ($board && $board['module'] === 'board' && BoardMoa_Boards::listable($board)) {
                $search = BoardMoa_Boards::adapterOf($board)->memberSearch($board, $id);
                if ($search) {
                    $actions[] = ['type' => 'documents', 'label' => BoardMoa_Text::t('작성글 보기'), 'mid' => $board['mid'], 'search' => $search];
                }
            }
            if (is_user_logged_in() && self::canInfo(self::target())) {
                $actions[] = ['type' => 'info', 'label' => BoardMoa_Text::t('회원 정보 보기')];
            }
        }
        return ['member_srl' => $id, 'actions' => $actions];
    }

    /** 회원 정보: 이름(표시 이름), 프로필 사진, 가입일, 소개(프로필의 '자기 소개'), 웹사이트 */
    public static function memberInfo()
    {
        $user = self::target();
        if (!$user) {
            throw new BoardMoa_Error(404, 'not_found', '없는 회원입니다.');
        }
        if (!self::canInfo($user)) {
            // 공개한 글이 없는 회원은 없는 회원과 같게 (웹 글쓴이 보관함처럼)
            throw new BoardMoa_Error(404, 'not_found', '없는 회원입니다.');
        }
        $fields = [];
        $bio = trim((string)get_the_author_meta('description', $user->ID));
        if ($bio !== '') {
            $fields[] = ['title' => BoardMoa_Text::t('자기소개'), 'name' => 'description', 'value' => BoardMoa_Html::text($bio)];
        }
        $url = trim((string)$user->user_url);
        if ($url !== '' && wp_http_validate_url($url)) {
            $fields[] = ['title' => BoardMoa_Text::t('홈페이지'), 'name' => 'homepage', 'value' => esc_url_raw($url)];
        }
        $fields[] = ['title' => BoardMoa_Text::t('가입일'), 'name' => 'regdate', 'value' => mysql2date(get_option('date_format'), get_date_from_gmt($user->user_registered))];
        return [
            'member_srl' => (int)$user->ID,
            'nick_name' => BoardMoa_Html::text($user->display_name),
            'profile_image' => BoardMoa_Api::avatar($user->ID),
            'regdate' => BoardMoa_Html::iso(get_date_from_gmt($user->user_registered)),
            'fields' => $fields,
        ];
    }

    /**
     * 가입 (1.0.28~): 웹 가입(wp-login.php?action=register)과 같은 register_new_user — 사용자명·메일 확인, 가입 훅(register_post·registration_errors:
     * CAPTCHA 4WP 등이 여기서 확인), 새 회원 알림(비밀번호를 정하는 링크를 메일로). 워드프레스는 가입할 때 비밀번호를 받지 않는다.
     * 예전 앱은 비밀번호 칸이 있는 양식을 그리므로 web_only 는 그대로 두고, 새 앱(2.0.8~)은 app_signup·password:false(새 필드)를 보고
     * 비밀번호 칸 없이 앱에서 가입한다. 멀티사이트 가입(wp-signup.php)은 웹에서.
     */
    public static function signupForm()
    {
        $enabled = (bool)get_option('users_can_register') && !is_multisite();
        $guarded = false;
        $widget = BoardMoa_Captcha::widget('registration', $guarded);
        return [
            'enabled' => (bool)get_option('users_can_register'),
            'web_only' => true,
            'app_signup' => $enabled && (!$guarded || $widget !== null),
            'password' => false,
            'captcha' => $guarded,
            'captcha_widget' => $widget,
            'web_url' => wp_registration_url(),
            'basic' => [
                ['name' => 'user_id', 'title' => BoardMoa_Text::t('사용자명'), 'required' => true],
                ['name' => 'email_address', 'title' => BoardMoa_Text::t('이메일'), 'required' => true],
            ],
            'agreements' => [],
            'password_hint' => BoardMoa_Text::t('가입하면 비밀번호를 정하는 링크를 메일로 보내 드립니다.'),
            'needs_confirm' => true,
            'fields' => [],
        ];
    }

    /** POST signup {user_id, email_address, captcha_response?} → {needs_confirm: true, message} */
    public static function signup()
    {
        if (!get_option('users_can_register') || is_multisite()) {
            throw new BoardMoa_Error(403, 'not_permitted', BoardMoa_Text::t('이 사이트는 지금 가입을 받지 않습니다.'), true);
        }
        BoardMoa_Captcha::check('registration');
        $login = sanitize_user((string)BoardMoa_Api::param('user_id', ''));
        $email = trim((string)BoardMoa_Api::param('email_address', ''));
        // 웹 가입 화면이 보내는 값과 같게 (register_new_user 는 받은 값을 쓰고, 가입 훅은 $_POST 를 본다)
        $_POST['user_login'] = $login;
        $_POST['user_email'] = $email;
        $result = register_new_user($login, $email);
        if (is_wp_error($result)) {
            if (BoardMoa_Captcha::isError($result)) {
                throw BoardMoa_Captcha::error('registration');
            }
            $message = trim(preg_replace('/^\s*(Error|오류)\s*:\s*/iu', '', wp_strip_all_tags(html_entity_decode($result->get_error_message(), ENT_QUOTES, 'UTF-8'))));
            throw new BoardMoa_Error(400, 'signup_failed', $message !== '' ? $message : BoardMoa_Text::t('가입하지 못했습니다.'), true);
        }
        return [
            'needs_confirm' => true,
            'message' => BoardMoa_Text::t('{0}로 비밀번호를 정하는 링크를 보냈습니다. 비밀번호를 정한 뒤 앱에서 로그인해 주세요.', $email),
        ];
    }

    // ---- 내 정보 수정 (웹의 프로필 화면 profile.php 와 같은 함수: wp_update_user)

    public static function form()
    {
        $user = wp_get_current_user();
        return [
            'nick_name' => (string)$user->display_name,
            'email_address' => (string)$user->user_email,
            'profile_image' => BoardMoa_Api::avatar($user->ID),
            'can_change_nickname' => true,
            // 메일을 바꾸면 워드프레스가 새 주소로 확인 메일을 보낸다(웹 프로필 화면) — 웹에서
            'can_change_email' => false,
            'profile_image_enabled' => false,
            // 웹 프로필 화면(wp-admin/profile.php)에서 회원이 고치는 이름·성·웹사이트·자기소개 (1.0.21~)
            'fields' => self::profileFields($user),
            'images' => [],
            'web_notice' => null,
            'web_url' => admin_url('profile.php'),
        ];
    }

    /** 웹 프로필 화면의 칸: 이름 => [제목, 형식] */
    private static function profileColumns()
    {
        return [
            'first_name' => ['이름', 'text'],
            'last_name' => ['성', 'text'],
            'user_url' => ['홈페이지', 'url'],
            'description' => ['자기소개', 'textarea'],
        ];
    }

    private static function profileFields($user)
    {
        $out = [];
        foreach (self::profileColumns() as $name => $info) {
            $out[] = ['name' => $name, 'title' => BoardMoa_Text::t($info[0]), 'type' => $info[1], 'required' => false,
                'value' => (string)$user->$name, 'options' => [], 'parts' => [], 'editable' => true];
        }
        return $out;
    }

    /**
     * 내 정보 수정·비밀번호 바꾸기의 지금 비밀번호 확인. 틀리면 웹 로그인 실패처럼 wp_login_failed 훅을 불러(로그인 제한·보안 플러그인이 센다)
     * 회원마다 10분 10번까지, 넘으면 429 too_many_attempts
     */
    private static function checkPassword($user)
    {
        $key = 'boardmoa_mepw_' . (int)$user->ID;
        BoardMoa_Api::limitCheck($key, 10, 600);
        $current = (string)BoardMoa_Api::param('current_password', '');
        if ($current === '' || !wp_check_password($current, $user->user_pass, $user->ID)) {
            BoardMoa_Api::limitHit($key, 600);
            do_action('wp_login_failed', $user->user_login, new WP_Error('incorrect_password', __('The password you entered is incorrect.')));
            throw new BoardMoa_Error(400, 'invalid_password', '지금 비밀번호가 맞지 않습니다.');
        }
    }

    public static function update()
    {
        $user = wp_get_current_user();
        self::checkPassword($user);
        $data = ['ID' => $user->ID];
        $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
        if ($nick !== '' && $nick !== $user->display_name) {
            $data['display_name'] = $nick;
            $data['nickname'] = $nick;
        }
        // 웹 프로필 화면과 같이 wp_update_user 가 걸러 저장한다(웹사이트 주소·자기소개 kses)
        $fields = BoardMoa_Api::param('fields');
        if (is_string($fields)) {
            $fields = json_decode($fields, true);
        }
        foreach (self::profileColumns() as $name => $info) {
            if (is_array($fields) && array_key_exists($name, $fields) && is_scalar($fields[$name])) {
                $value = trim((string)$fields[$name]);
                if ($value !== (string)$user->$name) {
                    $data[$name] = $name === 'user_url' ? esc_url_raw($value) : $value;
                }
            }
        }
        if (count($data) > 1) {
            $result = wp_update_user($data);
            if (is_wp_error($result)) {
                throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
            }
        }
        return BoardMoa_Api::profile(get_userdata($user->ID));
    }

    public static function password()
    {
        $user = wp_get_current_user();
        self::checkPassword($user);
        $new = (string)BoardMoa_Api::param('new_password', '');
        if (strlen($new) < 6) {
            throw new BoardMoa_Error(400, 'update_failed', '새 비밀번호가 너무 짧습니다.');
        }
        $result = wp_update_user(['ID' => $user->ID, 'user_pass' => $new]);
        if (is_wp_error($result)) {
            throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
        }
        // 다른 기기의 앱 토큰은 모두 무효, 이 기기에는 새 토큰
        BoardMoa_Store::revokeUser($user->ID);
        $user = get_userdata($user->ID);
        return ['tokens' => BoardMoa_Store::issue($user->ID, $user->user_pass, BoardMoa_Api::param('device_name', ''), BoardMoa_Api::param('platform', ''), BoardMoa_Api::ip())];
    }
}
