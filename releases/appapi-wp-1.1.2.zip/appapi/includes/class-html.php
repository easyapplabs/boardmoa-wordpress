<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 주소·시각·본문 HTML 도우미 */
class BoardMoa_Html
{
    public static function origin()
    {
        $home = home_url('/');
        $p = parse_url($home);
        return $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    }

    /** 절대 주소로 */
    public static function absolute($url)
    {
        $url = trim(html_entity_decode((string)$url, ENT_QUOTES, 'UTF-8'));
        if ($url === '' || preg_match('#^[a-z][a-z0-9+.\-]*:#i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return (is_ssl() ? 'https:' : 'http:') . $url;
        }
        if ($url[0] === '/') {
            return self::origin() . $url;
        }
        if ($url[0] === '#' || $url[0] === '?') {
            return $url;
        }
        return home_url('/') . ltrim($url, '/');
    }

    /** ISO 8601 (사이트 시간대). $local: 'Y-m-d H:i:s' 또는 'YmdHis' (사이트 시간) */
    public static function iso($local)
    {
        $local = (string)$local;
        if ($local === '' || strpos($local, '0000') === 0) {
            return null;
        }
        $format = preg_match('/^\d{14}$/', $local) ? 'YmdHis' : 'Y-m-d H:i:s';
        $date = DateTime::createFromFormat($format, $local, wp_timezone());
        return $date ? $date->format('c') : null;
    }

    /** 사이트 시간 → 유닉스 시각 (모아 보기 정렬용) */
    public static function timestamp($local)
    {
        $local = (string)$local;
        $format = preg_match('/^\d{14}$/', $local) ? 'YmdHis' : 'Y-m-d H:i:s';
        $date = DateTime::createFromFormat($format, $local, wp_timezone());
        return $date ? $date->getTimestamp() : 0;
    }

    /** 제목 등 글자: 태그를 빼고 HTML 엔티티를 푼다 */
    public static function text($html)
    {
        return trim(html_entity_decode(wp_strip_all_tags((string)$html), ENT_QUOTES, 'UTF-8'));
    }

    /** 목록 요약: 본문 글자 120자 */
    public static function summary($html, $length = 120)
    {
        $html = preg_replace('#<(script|style)\b.*?</\1>#is', '', (string)$html);
        $html = strip_shortcodes(preg_replace('/<!--.*?-->/s', '', $html));
        $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8')));
        return mb_substr($text, 0, $length);
    }

    /** 본문 속 첫 그림 (목록 썸네일) */
    public static function firstImage($html)
    {
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', (string)$html, $m)) {
            return self::absolute($m[1]);
        }
        return null;
    }

    /** 앱은 일반 글자로 보낸다: 태그는 글자로, 줄바꿈은 살린다 */
    public static function fromText($text)
    {
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)$text));
        if ($text === '') {
            return '';
        }
        $out = [];
        foreach (preg_split("/\n{2,}/", mb_substr($text, 0, 50000)) as $para) {
            $out[] = '<p>' . nl2br(esc_html($para), false) . '</p>';
        }
        return implode("\n", $out);
    }

    /** 앱 꾸밈 편집기의 HTML. 글자·사진이 없으면 빈 본문 */
    public static function fromEditor($html)
    {
        $html = trim((string)$html);
        if (trim(str_replace(['&nbsp;', "\xC2\xA0"], ' ', strip_tags($html, '<img><video><iframe>'))) === '') {
            return '';
        }
        return mb_substr($html, 0, 500000);
    }

    /** 앱이 보낸 본문 (content_format=html 이면 꾸밈 HTML, 아니면 일반 글자) */
    public static function contentParam()
    {
        $content = (string)BoardMoa_Api::param('content', '');
        return BoardMoa_Api::param('content_format') === 'html' ? self::fromEditor($content) : self::fromText($content);
    }

    /**
     * 앱에 보낼 본문 HTML: 상대 주소를 절대 주소로, 사이트 스크립트를 빼고(앱 화면에서는 돌지 않는다),
     * 같은 사이트의 글·게시판 링크에는 ?mid=…&document_srl=… 를 붙인다(앱이 글 화면으로 연다. 웹은 모르는 값을 무시한다).
     */
    public static function content($html)
    {
        $html = (string)$html;
        $html = self::smilies($html);
        $html = self::unlazy($html);
        $html = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $html);
        $html = preg_replace('/<!--.*?-->/s', '', $html);
        $html = preg_replace_callback('/\b(src|href|poster)\s*=\s*(["\'])(.*?)\2/i', function ($m) {
            $url = $m[3];
            if ($url === '' || $url[0] === '#' || stripos($url, 'javascript:') === 0 || stripos($url, 'data:') === 0) {
                return $m[0];
            }
            $abs = self::absolute($url);
            if (strtolower($m[1]) === 'href') {
                $abs = self::appLink($abs);
            }
            return $m[1] . '=' . $m[2] . esc_attr($abs) . $m[2];
        }, $html);
        $html = preg_replace_callback('/\bsrcset\s*=\s*(["\'])(.*?)\1/i', function ($m) {
            $parts = [];
            foreach (explode(',', $m[2]) as $item) {
                $item = trim($item);
                if ($item === '') {
                    continue;
                }
                $bits = preg_split('/\s+/', $item, 2);
                $parts[] = self::absolute($bits[0]) . (isset($bits[1]) ? ' ' . $bits[1] : '');
            }
            return 'srcset=' . $m[1] . esc_attr(implode(', ', $parts)) . $m[1];
        }, $html);
        // 워드프레스(6.7~)는 lazy 사진에 sizes="auto, …" 를 붙인다. 크롬(안드로이드 웹뷰)은 그런 사진에 브라우저 기본 규칙
        // contain: size !important; contain-intrinsic-size: 300px 150px 를 걸어(웹은 테마 CSS 가 덮는다) 앱 화면에서 사진이 납작해진다.
        // 앱 CSS 로는 덮을 수 없어 auto 만 뺀다 (나머지 sizes 값은 그대로라 고르는 사진 크기는 같다)
        $html = preg_replace_callback('/\ssizes\s*=\s*(["\'])\s*auto\s*(,\s*)?(.*?)\1/i', function ($m) {
            return trim($m[3]) === '' ? '' : ' sizes=' . $m[1] . $m[3] . $m[1];
        }, $html);
        return trim($html);
    }

    /**
     * 늦게 불러오기(lazy load) 플러그인이 본문 사진·동영상의 주소를 data-src 등에 옮기고 src 를 빈 그림으로 바꾼 것을 되돌린다.
     * 웹은 그 플러그인의 스크립트가 화면에 보일 때 바꿔 넣지만 앱 화면에는 스크립트가 없다 (앱은 스스로 늦게 불러온다).
     */
    /**
     * 워드프레스 웃음 표시(convert_smilies 의 <img class="wp-smiley" alt="🙂" style="height: 1em">)는 72×72 그림이고 웹은 CSS 로 글자 높이에 맞춘다.
     * 앱 화면은 그림을 원래 크기로 그려 커지므로, 그 자리를 그림의 alt(이모지 글자)로 바꾼다
     */
    public static function smilies($html)
    {
        if (stripos($html, 'wp-smiley') === false) {
            return $html;
        }
        return preg_replace_callback('/<img\b[^>]*\bclass\s*=\s*(["\'])[^"\']*\bwp-smiley\b[^"\']*\1[^>]*>/i', function ($m) {
            return preg_match('/\balt\s*=\s*(["\'])(.*?)\1/is', $m[0], $alt) && $alt[2] !== '' ? $alt[2] : $m[0];
        }, $html);
    }

    public static function unlazy($html)
    {
        if (stripos($html, 'data-') === false) {
            return $html;
        }
        return preg_replace_callback('/<(img|iframe|video|source)\b[^>]*>/i', function ($m) {
            $tag = $m[0];
            foreach (['src' => ['data-src', 'data-lazy-src', 'data-original', 'data-lazyload', 'data-ll-src'], 'srcset' => ['data-srcset', 'data-lazy-srcset'], 'sizes' => ['data-sizes', 'data-lazy-sizes']] as $attr => $sources) {
                foreach ($sources as $source) {
                    if (!preg_match('/\s' . preg_quote($source, '/') . '\s*=\s*(["\'])(.*?)\1/i', $tag, $v) || trim($v[2]) === '' || ($attr === 'sizes' && strtolower(trim($v[2])) === 'auto')) {
                        continue;
                    }
                    if (preg_match('/\s' . $attr . '\s*=\s*(["\'])(.*?)\1/i', $tag, $cur)) {
                        $current = trim($cur[2]);
                        // 이미 진짜 주소면 두고, 빈 그림(data:·blank·placeholder·lazy)이면 바꾼다
                        if ($current !== '' && stripos($current, 'data:') !== 0 && stripos($current, 'about:') !== 0 && !preg_match('/(blank|placeholder|lazy|spacer|transparent)[^\/]*\.(gif|png|svg)/i', $current)) {
                            break;
                        }
                        $tag = str_replace($cur[0], ' ' . $attr . '=' . $v[1] . $v[2] . $v[1], $tag);
                    } else {
                        $tag = preg_replace('/^<(\w+)/', '<$1 ' . $attr . '=' . $v[1] . $v[2] . $v[1], $tag);
                    }
                    break;
                }
            }
            return $tag;
        }, $html);
    }

    /**
     * 본문 속 양식(문의 양식·설문·가입 양식 등): 앱 화면에서는 보낼 수 없다(플러그인 스크립트·세션이 없고 보내는 곳이 앱 주소가 된다).
     * 검색 양식은 빼고(앱에 검색이 있다), 나머지는 그 자리에 웹 화면으로 가는 링크를 둔다.
     * 링크에 boardmoa_web=1 을 붙여 앱이 이 주소를 앱 화면으로 풀지 않고 브라우저로 연다(locate 가 풀지 않는다). 웹은 모르는 값을 무시한다.
     */
    public static function webOnlyForms($html, $webUrl)
    {
        if (stripos((string)$html, '<form') === false) {
            return $html;
        }
        $link = add_query_arg('boardmoa_web', '1', (string)$webUrl);
        return preg_replace_callback('#<form\b([^>]*)>.*?</form>#is', function ($m) use ($link) {
            if (preg_match('/\brole\s*=\s*["\']?search|class\s*=\s*["\'][^"\']*search/i', $m[1])) {
                return '';
            }
            return '<p class="bh-web-only"><a href="' . esc_url($link) . '">' . esc_html(BoardMoa_Text::t('이 양식은 웹 화면에서 쓸 수 있습니다.')) . '</a></p>';
        }, (string)$html);
    }

    /** 같은 사이트 링크면 앱이 알아보는 mid·document_srl 를 붙인다 */
    public static function appLink($url)
    {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if ($host === '' || $host !== strtolower((string)parse_url(home_url('/'), PHP_URL_HOST))) {
            return $url;
        }
        $query = (string)parse_url($url, PHP_URL_QUERY);
        if (strpos($query, 'document_srl=') !== false || strpos($query, 'mid=') !== false || strpos($query, 'boardmoa_web=') !== false) {
            return $url;
        }
        $found = BoardMoa_Boards::locate($url);
        if (!$found) {
            return $url;
        }
        $add = ['mid' => $found['mid']];
        if (!empty($found['document_srl'])) {
            $add['document_srl'] = $found['document_srl'];
        }
        $fragment = '';
        if (($pos = strpos($url, '#')) !== false) {
            $fragment = substr($url, $pos);
            $url = substr($url, 0, $pos);
        }
        return $url . (strpos($url, '?') === false ? '?' : '&') . http_build_query($add) . $fragment;
    }
}
