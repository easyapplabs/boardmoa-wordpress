<?php
if (!defined('ABSPATH')) {
    exit;
}

/** 관리 화면: 설정 → 게시판모아 (버전·업데이트·연결 주소·찾은 게시판·개발자에게 알리기). 관리자 언어(한국어·영어) */
class BoardMoa_Admin
{
    const SLUG = 'boardmoa';

    public static function init()
    {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_post_boardmoa_update', [__CLASS__, 'doUpdate']);
        add_action('admin_post_boardmoa_share', [__CLASS__, 'doShare']);
        add_filter('plugin_action_links_' . plugin_basename(BOARDMOA_FILE), [__CLASS__, 'links']);
        // 플러그인을 고쳐 올렸을 때(활성화 훅 없이)도 표를 만든다
        add_action('admin_init', ['BoardMoa_Store', 'ensureTables']);
    }

    public static function links($links)
    {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=' . self::SLUG)) . '">' . esc_html(BoardMoa_Text::t('설정')) . '</a>');
        return $links;
    }

    public static function menu()
    {
        add_options_page(BoardMoa_Text::t('게시판모아 앱 연동'), BoardMoa_Text::t('게시판모아'), 'manage_options', self::SLUG, [__CLASS__, 'render']);
    }

    private static function url($args = [])
    {
        return add_query_arg($args, admin_url('options-general.php?page=' . self::SLUG));
    }

    public static function doUpdate()
    {
        if (!current_user_can('manage_options') || !check_admin_referer('boardmoa_update')) {
            wp_die(esc_html(BoardMoa_Text::t('권한이 없습니다.')));
        }
        $result = BoardMoa_Updater::update();
        if (!empty($result['ok'])) {
            BoardMoa_Updater::report();
        }
        set_transient('boardmoa_update_result', $result, 300);
        wp_safe_redirect(self::url());
        exit;
    }

    public static function doShare()
    {
        if (!current_user_can('manage_options') || !check_admin_referer('boardmoa_share')) {
            wp_die(esc_html(BoardMoa_Text::t('권한이 없습니다.')));
        }
        update_option('boardmoa_share_site', isset($_POST['share_site']) && $_POST['share_site'] === 'Y' ? 'Y' : 'N', false);
        wp_safe_redirect(self::url());
        exit;
    }

    public static function render()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $t = function ($ko, ...$args) {
            return esc_html(BoardMoa_Text::t($ko, ...$args));
        };
        $check = isset($_GET['check']) ? BoardMoa_Updater::check() : null;
        $result = get_transient('boardmoa_update_result');
        if ($result) {
            delete_transient('boardmoa_update_result');
        }
        $apiUrl = plugins_url('api.php', BOARDMOA_FILE) . '?r=site';
        echo '<div class="wrap"><h1>' . $t('게시판모아 앱 연동') . '</h1>';
        echo '<p>' . $t('게시판모아(BoardMoa) 앱에서 이 사이트의 글과 게시판을 보고 쓸 수 있게 하는 플러그인입니다. 글을 읽고 쓸 수 있는 사람은 워드프레스와 각 게시판 플러그인의 권한 설정과 같습니다.') . '</p>';
        if ($result) {
            echo '<div class="notice ' . (!empty($result['ok']) ? 'notice-success' : 'notice-error') . '"><p>' . esc_html($result['message']);
            if (!empty($result['backup'])) {
                echo '<br><small>' . $t('이전 파일 백업: {0}', $result['backup']) . '</small>';
            }
            echo '</p></div>';
        }
        echo '<h2>' . $t('버전과 업데이트') . '</h2>';
        echo '<p>' . $t('설치된 버전: {0}', BoardMoa_Updater::currentVersion()) . '</p>';
        if ($check) {
            if ($check['error']) {
                echo '<div class="notice notice-warning inline"><p>' . esc_html($check['error']) . '</p></div>';
            } elseif ($check['has_update']) {
                echo '<p><strong>' . $t('새 버전: {0}', $check['latest']) . '</strong> (' . esc_html($check['date']) . ')</p>';
                if ($check['notes']) {
                    echo '<p style="white-space:pre-line">' . esc_html($check['notes']) . '</p>';
                }
                if (!$check['zip_available'] || !$check['writable']) {
                    echo '<div class="notice notice-warning inline"><p>' . $t('이 서버에서는 자동 업데이트를 할 수 없습니다. 공개 저장소에서 새 버전을 내려받아 플러그인 폴더를 직접 바꿔 주세요.') . '</p></div>';
                } else {
                    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                    wp_nonce_field('boardmoa_update');
                    echo '<input type="hidden" name="action" value="boardmoa_update"><button class="button button-primary">' . $t('{0} 버전으로 업데이트', $check['latest']) . '</button> ';
                    echo '<span class="description">' . $t('내려받은 파일의 전자서명을 확인하고, 지금 파일을 백업한 다음 새 파일로 바꿉니다.') . '</span></form>';
                }
            } elseif ($check['is_newer']) {
                echo '<p>' . $t('공개된 최신 버전({0})보다 새 버전이 설치되어 있습니다.', $check['latest']) . '</p>';
            } else {
                echo '<p>' . $t('최신 버전입니다.') . '</p>';
            }
        } else {
            echo '<p><a class="button" href="' . esc_url(self::url(['check' => 1])) . '">' . $t('업데이트 확인') . '</a></p>';
        }

        echo '<h2>' . $t('앱에 보이는 게시판') . '</h2><ul style="list-style:disc;padding-left:20px">';
        $names = ['core' => BoardMoa_Text::t('워드프레스 글'), 'kboard' => 'KBoard', 'mangboard' => BoardMoa_Text::t('망보드'), 'bbpress' => 'bbPress'];
        $count = [];
        foreach (BoardMoa_Boards::all() as $board) {
            $count[$board['adapter']] = (isset($count[$board['adapter']]) ? $count[$board['adapter']] : 0) + 1;
        }
        foreach (BoardMoa_Boards::adapters() as $key => $adapter) {
            echo '<li>' . esc_html(isset($names[$key]) ? $names[$key] : $key) . ' — ' . $t('게시판 {0}개', isset($count[$key]) ? $count[$key] : 0) . '</li>';
        }
        echo '</ul><p class="description">' . $t('앱의 메뉴는 사이트 메뉴(외모 → 메뉴, 블록 테마에서는 내비게이션)와 같게 구성됩니다. 사이트 메뉴에 없는 KBoard·망보드 게시판과 포럼은 앱의 ‘게시판’ 항목 아래에 모아서 표시됩니다. 볼 권한이 없는 게시판은 앱 어디에도 표시되지 않습니다.') . '</p>';

        echo '<h2>' . $t('설치 현황 — 개발자에게 알리기') . '</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('boardmoa_share');
        echo '<input type="hidden" name="action" value="boardmoa_share"><input type="hidden" name="share_site" value="N">';
        echo '<label><input type="checkbox" name="share_site" value="Y" ' . checked(BoardMoa_Updater::shareSite(), true, false) . ' onchange="this.form.submit()"> ' . $t('업데이트를 확인할 때 이 사이트 정보를 개발자에게 보내기') . '</label>';
        echo '<p class="description">' . $t('선택해 두면 [업데이트 확인]을 누를 때 사이트 주소, 사이트 이름, 엔진 종류와 버전, 플러그인 버전이 게시판모아 개발자(EasyAppLabs)에게 전송됩니다. 회원 정보와 글 내용은 전송되지 않으며, 전송된 정보는 공개하지 않습니다. 이 정보는 어떤 엔진과 버전에서 플러그인이 쓰이는지 파악해 호환성을 점검하고, 새 기능과 업데이트를 준비하는 데 사용합니다.') . '</p></form>';

        echo '<hr><p class="description">' . $t('앱 연결 주소:') . ' <a href="' . esc_url($apiUrl) . '" target="_blank">' . esc_html($apiUrl) . '</a><br>';
        echo $t('내려받기·설치 안내:') . ' <a href="https://github.com/easyapplabs/boardmoa-wordpress" target="_blank">github.com/easyapplabs/boardmoa-wordpress</a></p></div>';
    }
}
