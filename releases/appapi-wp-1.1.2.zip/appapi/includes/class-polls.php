<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 글 속 설문 (기능 polls, docs/API.md '글 속 설문') — WP-Polls 3.x.
 * 웹은 [poll id="…"] 숏코드·wp-polls/poll 블록 자리에 투표 양식(플러그인 스크립트·nonce 필요)을 그린다. 앱 화면에서는 그 양식을 보낼 수 없어
 * 새 앱(with_polls=1)에는 그 자리를 <div data-bh-poll="번호"></div> 로 두고 설문 값을 따로 준다. 예전 앱에는 웹 화면 링크(본문 속 양식과 같다).
 * 판단과 기록은 WP-Polls 의 함수 그대로: 투표할 수 있는 사람(allow_to_vote)·이미 투표(check_voted: 쿠키·IP·회원)·마감(pollq_active·만료)·
 * 고를 수 있는 수(pollq_multiple), 기록은 vote_poll_process (웹 투표와 같은 표·로그·훅).
 */
class BoardMoa_Polls
{
    /** @var int[]|null 지금 그리는 본문에서 바꾼 설문 번호 => 결과만 보이는 꼴(type=result) */
    private static $collected = null;

    public static function available()
    {
        return class_exists('WP_Polls_Vote') && class_exists('WP_Polls_Poll') && method_exists('WP_Polls_Vote', 'vote_poll_process');
    }

    /** 본문을 그리기 전: 설문 숏코드·블록을 자리표로 바꾸게 한다 */
    public static function begin()
    {
        if (!self::available()) {
            return false;
        }
        self::$collected = [];
        add_filter('pre_do_shortcode_tag', [__CLASS__, 'shortcode'], 10, 3);
        add_filter('pre_render_block', [__CLASS__, 'block'], 10, 2);
        return true;
    }

    /** @var string|null 예전 앱·페이지: 설문 자리에 둘 웹 화면 주소 */
    private static $webUrl = null;

    /** 설문 카드를 쓰지 않는 화면(예전 앱·페이지): 설문 자리 전체를 웹 화면 링크로 (양식만 바꾸면 '불러오는 중' 부품이 남는다) */
    public static function beginLink($webUrl)
    {
        if (!self::available() || self::$collected !== null) {
            return false;
        }
        self::$webUrl = (string)$webUrl;
        add_filter('pre_do_shortcode_tag', [__CLASS__, 'shortcode'], 10, 3);
        add_filter('pre_render_block', [__CLASS__, 'block'], 10, 2);
        return true;
    }

    public static function endLink()
    {
        self::$webUrl = null;
        remove_filter('pre_do_shortcode_tag', [__CLASS__, 'shortcode'], 10);
        remove_filter('pre_render_block', [__CLASS__, 'block'], 10);
    }

    /** 본문을 그린 뒤: [번호 => 결과만] */
    public static function end()
    {
        remove_filter('pre_do_shortcode_tag', [__CLASS__, 'shortcode'], 10);
        remove_filter('pre_render_block', [__CLASS__, 'block'], 10);
        $ids = self::$collected ?: [];
        self::$collected = null;
        return $ids;
    }

    public static function shortcode($output, $tag, $attr)
    {
        if ($tag !== 'poll') {
            return $output;
        }
        $attr = (array)$attr;
        $id = isset($attr['id']) ? (int)$attr['id'] : (isset($attr[0]) ? (int)trim((string)$attr[0], '="\'') : 0);
        return self::placeholder($id, isset($attr['type']) ? (string)$attr['type'] : 'vote', $output);
    }

    public static function block($output, $block)
    {
        if (!isset($block['blockName']) || $block['blockName'] !== 'wp-polls/poll') {
            return $output;
        }
        $attrs = isset($block['attrs']) ? (array)$block['attrs'] : [];
        return self::placeholder(isset($attrs['id']) ? (int)$attrs['id'] : 0, isset($attrs['type']) ? (string)$attrs['type'] : 'vote', $output);
    }

    private static function placeholder($id, $type, $fallback)
    {
        if (self::$webUrl !== null) {
            return '<p class="bh-web-only"><a href="' . esc_url(add_query_arg('boardmoa_web', '1', self::$webUrl)) . '">' . esc_html(BoardMoa_Text::t('설문은 웹 화면에서 할 수 있습니다.')) . '</a></p>';
        }
        $id = self::resolveId($id);
        if ($id <= 0 || !WP_Polls_Poll::get($id) || !in_array($type, ['vote', 'result'], true)) {
            return $fallback; // 무작위·꺼진 설문 등은 웹처럼 그린다 (양식이면 웹 화면 링크가 된다)
        }
        self::$collected[$id] = (isset(self::$collected[$id]) ? self::$collected[$id] : true) && $type === 'result';
        return '<div data-bh-poll="' . $id . '"></div>';
    }

    /** 번호 0 은 WP-Polls 의 '지금 설문'(설정, 없으면 가장 최근 설문) */
    private static function resolveId($id)
    {
        $id = (int)$id;
        if ($id !== 0) {
            return $id;
        }
        $current = class_exists('WP_Polls_Options') ? (int)WP_Polls_Options::get('current_poll') : 0;
        if ($current > 0) {
            return $current;
        }
        if ($current === 0 && class_exists('WP_Polls_Options')) {
            return (int)WP_Polls_Options::get('latest_poll');
        }
        return 0;
    }

    private static function unslash($text)
    {
        return function_exists('removeslashes') ? removeslashes($text) : stripslashes((string)$text);
    }

    /** 앱의 설문 값 */
    public static function data($id, $resultOnly = false)
    {
        $poll = WP_Polls_Poll::get((int)$id);
        if (!$poll) {
            return null;
        }
        $answers = [];
        foreach ((array)WP_Polls_Poll::answers((int)$id) as $a) {
            $answers[] = ['id' => (int)$a->polla_aid, 'title' => BoardMoa_Html::text(self::unslash($a->polla_answers)), 'count' => (int)$a->polla_votes];
        }
        $multiple = (int)$poll->pollq_multiple;
        $max = $multiple > 0 ? $multiple : 1;
        $expiry = (int)$poll->pollq_expiry;
        $ended = !(int)$poll->pollq_active || ($expiry > 0 && $expiry < current_time('timestamp'));
        $voted = !empty(WP_Polls_Vote::check_voted((int)$id));
        $allowed = WP_Polls_Vote::check_allowtovote();
        $allowTo = class_exists('WP_Polls_Options') ? (int)WP_Polls_Options::get('allow_to_vote') : 2;
        $question = BoardMoa_Html::text(self::unslash($poll->pollq_question));
        return [
            'id' => (int)$poll->pollq_id,
            'title' => null,
            'questions' => [[
                'id' => (int)$poll->pollq_id,
                'title' => $question,
                'checkcount' => $max,
                'min_choices' => 1,
                'max_choices' => $max,
                // 비율의 분모: 여럿 고르는 설문은 투표한 사람, 하나만 고르는 설문은 표 (WP-Polls 결과 화면과 같다)
                'count' => $multiple > 0 ? (int)$poll->pollq_totalvoters : (int)$poll->pollq_totalvotes,
                'choices' => $answers,
            ]],
            'participants' => (int)$poll->pollq_totalvoters,
            'end_date' => $expiry > 0 ? date('Y-m-d', $expiry) : null,
            'ended' => $ended,
            'voted' => $voted,
            'can_vote' => !$resultOnly && !$ended && !$voted && $allowed,
            // 회원만 투표하는 설문 (allow_to_vote 1)
            'login_required' => $allowTo === 1 && !is_user_logged_in(),
            'result_visible' => true,
        ];
    }

    /** POST poll.vote {mid, document_srl, poll_id, choices} */
    public static function vote($ids, $pollId, $choices)
    {
        $pollId = (int)$pollId;
        if (!isset($ids[$pollId])) {
            throw new BoardMoa_Error(404, 'poll_not_found', '없는 설문입니다.');
        }
        $data = self::data($pollId, $ids[$pollId]);
        if (!$data) {
            throw new BoardMoa_Error(404, 'poll_not_found', '없는 설문입니다.');
        }
        if ($data['ended']) {
            throw new BoardMoa_Error(400, 'poll_ended', '마감된 설문입니다.');
        }
        if ($data['login_required']) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $valid = array_map(function ($c) {
            return $c['id'];
        }, $data['questions'][0]['choices']);
        $choices = array_values(array_unique(array_map('intval', is_array($choices) ? $choices : explode(',', (string)$choices))));
        if (!$choices || count($choices) > $data['questions'][0]['max_choices'] || array_diff($choices, $valid)) {
            throw new BoardMoa_Error(400, 'invalid_choice', '고른 답이 맞지 않습니다.');
        }
        if (!$data['can_vote']) {
            throw new BoardMoa_Error(400, 'vote_failed', $data['voted'] ? '이미 투표했습니다.' : '이 설문에는 투표할 수 없습니다.');
        }
        try {
            WP_Polls_Vote::vote_poll_process($pollId, $choices);
        } catch (Exception $e) {
            throw new BoardMoa_Error(400, 'vote_failed', html_entity_decode($e->getMessage(), ENT_QUOTES, 'UTF-8'), true);
        }
        return ['poll' => self::data($pollId, $ids[$pollId])];
    }
}
