<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 망보드 (Mangboard). 게시판은 숏코드 [mb_board name="이름"] 로 페이지에 들어 있다(또는 게시판 설정의 post_id).
 * 권한은 망보드의 회원 레벨 규칙을 그대로 따른다 (mbw_is_permission_level·mbw_is_secret 와 같은 판단):
 *  - 목록: 관리자 또는 list_level <= 회원 레벨, 글 보기: view_level <= 레벨 또는 자기 글
 *  - 비밀글: 비밀글 보기 레벨(secret_level) 이상이거나 자기 글·자기 글의 답글, 또는 글 비밀번호(mbw_check_password)
 *  - 회원 레벨은 망보드가 웹과 같이 정한 값(mbw_get_user('fn_user_level'), 비회원 0)
 * 쓰기(글·댓글·고치기·지우기·추천)는 웹 화면이 부르는 망보드 처리기(admin-ajax 의 mb_board·mb_comment = api/mb-board.php·mb-comment.php)를
 * 이 요청 안에서 새 망보드 요청처럼 실행한다(run): 레벨 권한·비밀번호 확인·필수 항목·금지어·포인트·훅이 웹과 같다.
 */
class BoardMoa_Mangboard extends BoardMoa_Adapter
{
    private $boards = null;
    private $rows = [];

    public function key()
    {
        return 'mangboard';
    }

    public function available()
    {
        return defined('_MB_') && function_exists('mbw_get_user') && function_exists('mbw_check_password') && function_exists('mbw_api_callback') && class_exists('MStore');
    }

    public function features()
    {
        $features = ['guest_write', 'guest_manage', 'guest_comment', 'reply_write', 'file_upload'];
        foreach ($this->boards() as $b) {
            $row = $this->row($b);
            if ((int)$row->use_comment === 1 && ((int)$row->use_comment_vote_good === 1 || (int)$row->use_comment_vote_bad === 1)) {
                $features[] = 'comment_vote'; // 댓글 추천을 켠 게시판이 있을 때
                break;
            }
        }
        if (function_exists('mbw_api_header_kcaptcha') && (int)mbw_get_option('kcaptcha_mode') && BoardMoa_Captcha::appSolvesImage()) {
            $features[] = 'captcha_solve';
        }
        return $features;
    }

    private function prefix()
    {
        global $mb_table_prefix;
        return (string)$mb_table_prefix;
    }

    public function boards()
    {
        global $wpdb;
        if ($this->boards === null) {
            $this->boards = [];
            $table = $this->prefix() . 'boards';
            $rows = $wpdb->get_results("SELECT * FROM `$table` WHERE board_type = 'board' AND is_show = 1 ORDER BY pid");
            $pages = [];
            $listTypes = [];
            foreach ((array)$wpdb->get_results("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_type IN ('page','post') AND post_status IN ('publish','private') AND post_content LIKE '%[mb_board%' ORDER BY post_status = 'publish' DESC, ID") as $p) {
                if (preg_match_all('/\[mb_board\s[^\]]*\bname\s*=\s*["\']?([A-Za-z0-9_]+)[^\]]*\]/i', $p->post_content, $m, PREG_SET_ORDER)) {
                    foreach ($m as $sc) {
                        $name = $sc[1];
                        if (!isset($pages[$name])) {
                            $pages[$name] = (int)$p->ID;
                            // 목록 모양(숏코드 list_type): 갤러리형은 웹이 사진 없는 글·비밀글을 목록에서 뺀다 (1.1.1~)
                            $listTypes[$name] = preg_match('/\blist_type\s*=\s*["\']?([a-z]+)/i', $sc[0], $lt) ? strtolower($lt[1]) : '';
                        }
                    }
                }
            }
            foreach ((array)$rows as $row) {
                $name = (string)$row->board_name;
                $page = isset($pages[$name]) ? $pages[$name] : (int)$row->post_id;
                if (!$page || !get_post($page) || !preg_match('/^[A-Za-z0-9_]{1,60}$/', $name)) {
                    continue; // 페이지에 넣지 않은 게시판은 웹에서 열 곳이 없다
                }
                $mid = 'mb-' . str_replace('_', '-', strtolower($name));
                $this->rows[$mid] = $row;
                $this->boards[$mid] = ['mid' => $mid, 'adapter' => 'mangboard', 'module' => 'board', 'ref' => $name, 'page' => $page,
                    'list_type' => isset($listTypes[$name]) ? $listTypes[$name] : '',
                    'title' => BoardMoa_Html::text($row->description !== '' ? $row->description : $name), 'url' => get_permalink($page)];
            }
        }
        return $this->boards;
    }

    private function row($board)
    {
        $this->boards();
        return $this->rows[$board['mid']];
    }

    private function table($board, $comment = false)
    {
        $row = $this->row($board);
        $name = $row->table_link !== '' ? $row->table_link : $row->board_name;
        return $this->prefix() . preg_replace('/[^A-Za-z0-9_]/', '', $name) . ($comment ? '_comment' : '');
    }

    private static function level()
    {
        return (int)mbw_get_user('fn_user_level');
    }

    private static function admin()
    {
        return (bool)mbw_is_admin();
    }

    private static function userPid()
    {
        return mbw_is_login() ? (int)mbw_get_user('fn_pid') : 0;
    }

    public function fromMenuNode($node)
    {
        if (isset($node['type']) && $node['type'] === 'post_type' && !empty($node['object_id'])) {
            foreach ($this->boards() as $b) {
                if ((int)$b['page'] === (int)$node['object_id']) {
                    return ['mid' => $b['mid'], 'expand' => null];
                }
            }
            // 같은 게시판을 넣은 다른 페이지(다국어 사이트의 번역 페이지 등)도 그 게시판이다
            if (preg_match('/\[mb_board\s[^\]]*\bname\s*=\s*["\']?([A-Za-z0-9_]+)/i', (string)get_post_field('post_content', (int)$node['object_id']), $m)) {
                foreach ($this->boards() as $b) {
                    if ($b['ref'] === $m[1]) {
                        return ['mid' => $b['mid'], 'expand' => null];
                    }
                }
            }
        }
        return null;
    }

    public function menuBoards()
    {
        $out = [];
        foreach ($this->boards() as $b) {
            $out[] = ['mid' => $b['mid'], 'title' => $b['title']];
        }
        return $out;
    }

    public function canList($board)
    {
        $page = get_post((int)$board['page']);
        if (!$page || !BoardMoa_Core::readable($page)) {
            return false;
        }
        return self::admin() || (int)$this->row($board)->list_level <= self::level();
    }

    /** 레벨 하나가 이 회원에게 되는가 (mbw_is_permission_level: 관리자는 늘 된다) */
    private function allows($level)
    {
        return self::admin() || (int)$level <= self::level();
    }

    /** 댓글 쓰기 레벨: 댓글 레벨과 보기 레벨 중 큰 것 (mbw_is_permission_level 의 mode=comment) */
    private function commentLevel($row)
    {
        return max((int)$row->comment_level, (int)$row->view_level);
    }

    public function grant($board)
    {
        $row = $this->row($board);
        $list = $this->canList($board);
        return [
            'list' => $list,
            'view' => $list && $this->allows($row->view_level),
            'write_document' => $list && $this->allows($row->write_level),
            'write_comment' => $list && (int)$row->use_comment === 1 && $this->allows($this->commentLevel($row)),
            'manager' => $this->allows($row->manage_level),
        ];
    }

    /**
     * 망보드 그림 글자 CAPTCHA(kcaptcha 플러그인): 설정 kcaptcha_mode 가 켜져 있고 스킨의 글쓰기·댓글 양식에 그림 글자 칸이 이 회원 레벨에 나오면
     * 웹은 그 칸을 채워야 받는다. 새 앱은 그림(type image)을 받아 풀고, 예전 앱은 위젯 없이 captcha_required (웹으로 안내한다)
     */
    private function captchaNeeded($board, $comment)
    {
        if (!function_exists('mbw_api_header_kcaptcha') || !(int)mbw_get_option('kcaptcha_mode') || self::admin()) {
            return false;
        }
        $model = $this->model($board, $comment ? 'comment_write' : 'write');
        foreach ($model as $item) {
            if (isset($item['type']) && $item['type'] === 'kcaptcha_img' && mbw_check_item($item)) {
                return true;
            }
        }
        return false;
    }

    private function captchaWidget($board, $comment)
    {
        return BoardMoa_Captcha::imageWidget($board['mid'], $comment ? 'comment' : 'document', 6, 'number');
    }

    /** 망보드 그림 글자(kcaptcha 플러그인의 KCAPTCHA, kcaptcha_image.php 와 같은 그림). 답은 번호로 둔다 */
    public function captchaImage($board, $for)
    {
        if (!function_exists('mbw_api_header_kcaptcha') || !(int)mbw_get_option('kcaptcha_mode')) {
            return parent::captchaImage($board, $for);
        }
        $dir = dirname((new ReflectionFunction('mbw_api_header_kcaptcha'))->getFileName());
        if (!class_exists('KCAPTCHA')) {
            require_once $dir . '/class.kcaptcha.php';
        }
        ob_start();
        $captcha = new KCAPTCHA();
        $bytes = (string)ob_get_clean();
        if (function_exists('header_remove')) {
            header_remove('Content-Type');
        }
        $key = (string)$captcha->getKeyString();
        if ($key === '' || $bytes === '') {
            throw new BoardMoa_Error(500, 'server_error', '자동 입력 방지 그림을 만들지 못했습니다.');
        }
        return BoardMoa_Captcha::imageResult($key, $bytes, strlen($key), 'number');
    }

    /** 그림 글자가 필요하면 앱이 푼 답을 웹처럼: 그 번호의 답을 망보드가 보는 세션 자리(모드_동작_captcha_keystring)에, 읽은 글자를 kcaptcha_img 로 */
    private function captchaFields($board, $comment, array &$fields)
    {
        if (!$this->captchaNeeded($board, $comment)) {
            return;
        }
        $widget = $this->captchaWidget($board, $comment);
        $kept = $widget ? BoardMoa_Captcha::take(BoardMoa_Api::param('captcha_response', '')) : null;
        if (!$kept || $kept[1] === '') {
            throw new BoardMoa_Error(403, 'captcha_required', $widget ? '자동 입력 방지 확인이 필요합니다.' : '이 게시판은 웹에서 자동 입력 방지 확인을 해야 글을 쓸 수 있습니다.', false, ['captcha' => $widget]);
        }
        BoardMoa_Captcha::session();
        $mode = preg_replace('/[^0-9a-zA-Z\_\-]/', '', $fields['mode'] . '_' . $fields['board_action']);
        $_SESSION[$mode . '_captcha_keystring'] = $kept[0];
        $fields['kcaptcha_img'] = $kept[1];
        self::$captchaRetry = $widget;
    }

    /** 그림 글자 답이 틀렸을 때 다시 풀 위젯 (captchaFields 가 넣는다) */
    private static $captchaRetry = null;

    /**
     * 스킨 모델(글쓰기·댓글 양식의 칸 목록): 망보드가 게시판을 열 때(MStore::set_board_options) 읽는 파일과 같은 곳 —
     * 게시판 설정의 모델(models/<이름>.php) 또는 스킨(테마의 mangboard/skins·스토어·플러그인 순서)의 includes/skin-model.php
     */
    private function model($board, $key)
    {
        static $cache = [];
        $id = $board['mid'] . ':' . $key;
        if (array_key_exists($id, $cache)) {
            return $cache[$id];
        }
        $cache[$id] = [];
        $row = $this->row($board);
        $skin = str_replace('..', '', (string)$row->skin_name);
        $store = str_replace('..', '', (string)mbw_get_option('store_path'));
        $model = str_replace('..', '', (string)$row->model_name);
        if ($model !== '') {
            $path = ($store !== '' && is_file(WP_CONTENT_DIR . $store . 'models/' . $model . '.php')) ? WP_CONTENT_DIR . $store . 'models/' . $model . '.php' : MBW_PLUGIN_PATH . 'models/' . $model . '.php';
        } elseif ($skin !== '') {
            $base = MBW_PLUGIN_PATH;
            if (is_dir(get_stylesheet_directory() . '/' . MBW_PLUGIN_DIR . '/skins/' . $skin . '/')) {
                $base = get_stylesheet_directory() . '/' . MBW_PLUGIN_DIR . '/';
            } elseif ($store !== '' && is_dir(WP_CONTENT_DIR . $store . 'skins/' . $skin . '/')) {
                $base = WP_CONTENT_DIR . $store;
            }
            $path = $base . 'skins/' . $skin . '/includes/skin-model.php';
        } else {
            return $cache[$id];
        }
        if (!is_file($path)) {
            return $cache[$id];
        }
        $models = (function ($path) {
            $desktop_model = [];
            include $path;
            return $desktop_model;
        })($path);
        if (!empty($models[$key])) {
            $data = mbw_json_decode($models[$key]);
            $cache[$id] = is_array($data) ? $data : [];
        }
        return $cache[$id];
    }

    private function categoryNames($board)
    {
        $row = $this->row($board);
        if ($row->category_type === 'NONE' || trim((string)$row->category_data) === '') {
            return [];
        }
        $json = json_decode((string)$row->category_data, true);
        $names = is_array($json) ? array_keys($json) : array_map('trim', explode(',', (string)$row->category_data));
        return array_values(array_filter(array_map('strval', $names), 'strlen'));
    }

    private function info($board, $grant)
    {
        $row = $this->row($board);
        $loggedIn = is_user_logged_in();
        $categories = [];
        foreach ($this->categoryNames($board) as $i => $name) {
            $categories[] = ['category_srl' => $i + 1, 'parent_srl' => 0, 'title' => $name, 'document_count' => 0, 'writable' => (bool)$grant['write_document']];
        }
        $captcha = ['document' => $grant['write_document'] && $this->captchaNeeded($board, false), 'comment' => $grant['write_comment'] && $this->captchaNeeded($board, true)];
        return $this->boardInfo($board, $grant, [
            'columns' => ['read_count' => true, 'vote_count' => (bool)$row->use_board_vote_good],
            'use_secret' => (int)$row->use_secret === 1,
            'categories' => $categories,
            'write_url' => add_query_arg(['mode' => 'write', 'board_action' => 'write'], get_permalink((int)$board['page'])),
            'captcha' => $captcha,
            'upload' => $grant['write_document'] ? $this->uploadInfo($board) + ['files' => $this->attachInfo($board, null)] : self::noUpload(),
            'captcha_widget' => $captcha['document'] ? $this->captchaWidget($board, false) : ($captcha['comment'] ? $this->captchaWidget($board, true) : null),
            'guest_fields' => ($grant['write_document'] && !$loggedIn) ? ['nick_name', 'password'] : null,
            'guest_comment_fields' => ($grant['write_comment'] && !$loggedIn) ? ['nick_name', 'password'] : null,
            // 웹: 비회원 글의 고치기·지우기는 비회원에게만 비밀번호로 (회원에게는 단추가 없다)
            'guest_certify_fields' => $loggedIn ? null : ['password'],
        ]);
    }

    private function categoryName($board)
    {
        $cat = BoardMoa_Api::intParam('category');
        $names = $this->categoryNames($board);
        return ($cat && isset($names[$cat - 1])) ? $names[$cat - 1] : null;
    }

    public function listPage($board)
    {
        global $wpdb;
        $grant = $this->grant($board);
        $row = $this->row($board);
        list($page, $perPage) = self::pageArgs((int)$row->page_size ?: 20);
        $table = $this->table($board);
        $where = ['1=1'];
        $args = [];
        // 웹 갤러리형 목록과 같게: 사진 없는 글·비밀글은 뺀다 (망보드 스킨 skin-settings.php 의 list_type=gallery)
        if (($board['list_type'] ?? '') === 'gallery') {
            $where[] = "image_path != ''";
            $where[] = 'is_secret = 0';
        }
        if (($cat = $this->categoryName($board)) !== null) {
            $where[] = 'category1 = %s';
            $args[] = $cat;
        }
        // 이름 메뉴의 '작성 글 보기' (member_srl = 워드프레스 회원 번호 → 망보드 회원 번호): 검색처럼 비밀글 보기 레벨이 안 되면 비밀글은 뺀다
        $member = BoardMoa_Api::intParam('member_srl');
        $filtered = false;
        if ($member > 0) {
            $where[] = 'user_pid = %d';
            $args[] = $this->mbUserPid($member);
            $filtered = true;
            if ((int)$row->secret_level > self::level() && !self::admin()) {
                $where[] = 'is_secret = 0';
            }
        }
        list($keyword, $target) = self::search();
        if ($keyword !== '') {
            $like = '%' . $wpdb->esc_like($keyword) . '%';
            if ($target === 'title') {
                $where[] = 'title LIKE %s';
                $args[] = $like;
            } elseif ($target === 'content') {
                $where[] = 'content LIKE %s';
                $args[] = $like;
            } elseif ($target === 'nick_name' || $target === 'user_id') {
                $where[] = 'user_name LIKE %s';
                $args[] = $like;
            } else {
                $where[] = '(title LIKE %s OR content LIKE %s)';
                $args[] = $like;
                $args[] = $like;
            }
            // 웹 검색: 비밀글 보기 레벨이 안 되면 비밀글은 검색 결과에서 뺀다
            if ((int)$row->secret_level > self::level() && !self::admin()) {
                $where[] = 'is_secret = 0';
            }
        }
        $w = implode(' AND ', $where);
        $total = (int)$wpdb->get_var($args ? $wpdb->prepare("SELECT COUNT(*) FROM `$table` WHERE $w AND is_notice = 0", $args) : "SELECT COUNT(*) FROM `$table` WHERE $w AND is_notice = 0");
        // 웹 목록과 같은 순서: 글 묶음(gid) 최신순, 묶음 안은 답글 순서(reply) — 답글은 원글 아래에 들여 쓴다(reply_depth)
        $sql = "SELECT * FROM `$table` WHERE $w AND is_notice = 0 ORDER BY gid DESC, reply ASC LIMIT %d, %d";
        $items = $wpdb->get_results($wpdb->prepare($sql, array_merge($args, [($page - 1) * $perPage, $perPage])));
        $notices = [];
        if ($page === 1 && $keyword === '' && !$filtered && $row->use_notice) {
            foreach ((array)$wpdb->get_results("SELECT * FROM `$table` WHERE is_notice = 1 ORDER BY gid DESC") as $n) {
                $notices[] = $this->summarize($board, $n);
            }
        }
        $documents = [];
        foreach ((array)$items as $item) {
            $documents[] = $this->summarize($board, $item);
        }
        return ['board' => $this->info($board, $grant), 'notices' => $notices, 'documents' => $documents, 'page' => $page,
            'total_pages' => max(1, (int)ceil($total / $perPage)), 'total_count' => $total];
    }

    public function recent($board, $limit)
    {
        global $wpdb;
        $table = $this->table($board);
        $out = [];
        foreach ((array)$wpdb->get_results($wpdb->prepare("SELECT * FROM `$table` ORDER BY reg_date DESC LIMIT %d", $limit)) as $item) {
            $out[] = ['time' => BoardMoa_Html::timestamp($item->reg_date), 'summary' => $this->summarize($board, $item)];
        }
        return $out;
    }

    /** 워드프레스 회원 → 망보드 회원 번호 (없으면 0: 아무 글도 고르지 않는다) */
    private function mbUserPid($userId)
    {
        global $wpdb;
        $user = get_userdata((int)$userId);
        if (!$user) {
            return -1;
        }
        $pid = (int)$wpdb->get_var($wpdb->prepare('SELECT pid FROM `' . $this->prefix() . 'users` WHERE wp_user_pid = %d OR user_id = %s ORDER BY wp_user_pid = %d DESC LIMIT 1', $user->ID, $user->user_login, $user->ID));
        return $pid > 0 ? $pid : -1;
    }

    public function memberSearch($board, $userId)
    {
        // 회원이 있는지와 상관없이 같은 모양 (망보드 회원이 아니면 빈 목록)
        return ['member_srl' => (string)(int)$userId];
    }

    /**
     * 웹 이름 팝업(api/mb-template.php): 작성글 검색(그 게시판), 메일(망보드 레벨 10 이상), 홈페이지, 블로그(회원이 적어 둔 때만).
     * 회원 정보 화면은 웹에 없다. 팝업 끄기 설정(show_name_popup)이면 이름에 메뉴가 없다
     */
    public function webNameMenu($board, $userId)
    {
        global $wpdb;
        if (function_exists('mbw_get_option') && mbw_get_option('show_name_popup') === 0) {
            return [];
        }
        $actions = [];
        if (BoardMoa_Boards::listable($board)) {
            $actions[] = ['type' => 'documents', 'label' => BoardMoa_Text::t('작성글 보기'), 'mid' => $board['mid'], 'search' => $this->memberSearch($board, $userId)];
        }
        $row = $wpdb->get_row($wpdb->prepare('SELECT user_email, user_homepage, user_blog FROM `' . $this->prefix() . 'users` WHERE wp_user_pid = %d LIMIT 1', (int)$userId));
        if (!$row) {
            return $actions;
        }
        $me = get_current_user_id();
        $level = $me ? (int)$wpdb->get_var($wpdb->prepare('SELECT user_level FROM `' . $this->prefix() . 'users` WHERE wp_user_pid = %d LIMIT 1', $me)) : 0;
        if ($level >= 10 && is_email((string)$row->user_email)) {
            $actions[] = ['type' => 'email', 'label' => BoardMoa_Text::t('메일 보내기'), 'email' => (string)$row->user_email];
        }
        if (wp_http_validate_url((string)$row->user_homepage)) {
            $actions[] = ['type' => 'link', 'label' => BoardMoa_Text::t('홈페이지'), 'url' => esc_url_raw((string)$row->user_homepage)];
        }
        if (wp_http_validate_url((string)$row->user_blog)) {
            $actions[] = ['type' => 'link', 'label' => BoardMoa_Text::t('블로그'), 'url' => esc_url_raw((string)$row->user_blog)];
        }
        return $actions;
    }

    private function num($board, $pid)
    {
        return BoardMoa_Store::num('mb:' . $board['ref'] . ':' . (int)$pid);
    }

    private function pid($board, $srl)
    {
        $ref = BoardMoa_Store::ref($srl);
        $prefix = 'mb:' . $board['ref'] . ':';
        return ($ref && strpos($ref, $prefix) === 0) ? (int)substr($ref, strlen($prefix)) : 0;
    }

    private function commentNum($board, $pid)
    {
        return BoardMoa_Store::num('mbc:' . $board['ref'] . ':' . (int)$pid);
    }

    /** 망보드 mbw_is_secret 와 같은 판단: 비밀글을 이 사람이 읽을 수 있는가 */
    private function secretOpen($board, $item, $password = '')
    {
        if (!(int)$item->is_secret) {
            return true;
        }
        $row = $this->row($board);
        $me = self::userPid();
        if (mbw_is_login()) {
            if ((int)$row->secret_level <= self::level() || ($me && ($me === (int)$item->user_pid || $me === (int)$item->parent_user_pid))) {
                return true;
            }
        }
        return $password !== '' && $item->passwd !== '' && mbw_check_password($password, $item->passwd);
    }

    /** 글 보기 레벨 (자기 글은 레벨과 상관없이) */
    private function viewable($board, $item)
    {
        $row = $this->row($board);
        $me = self::userPid();
        return self::admin() || (int)$row->view_level <= self::level() || ($me && $me === (int)$item->user_pid);
    }

    private function contentHtml($item)
    {
        $content = (string)$item->content;
        if ($item->data_type === 'html') {
            $html = mbw_htmlspecialchars_decode($content);
            // 웹 본문 화면(skin-filters.php 의 fn_content)과 같다: 비회원(레벨 0)이 쓴 글은 HTML Purifier 로 한 번 더 거른다
            if (!isset($item->level) || (int)$item->level === 0) {
                if (!function_exists('mbw_get_htmlpurify') && defined('MBW_PLUGIN_PATH') && is_file(MBW_PLUGIN_PATH . 'plugins/htmlpurifier/htmlpurifier.php')) {
                    include_once MBW_PLUGIN_PATH . 'plugins/htmlpurifier/htmlpurifier.php';
                }
                $html = function_exists('mbw_get_htmlpurify') ? mbw_get_htmlpurify($html) : wp_kses_post($html);
            }
            return $html;
        }
        return nl2br(esc_html(html_entity_decode($content, ENT_QUOTES, 'UTF-8')), false);
    }

    /** 글쓴이 워드프레스 회원: 망보드 회원(user_pid)의 wp_user_pid, 없으면 아이디 */
    private function wpUserOf($userPid, $userId = '')
    {
        global $wpdb;
        static $cache = [];
        $userPid = (int)$userPid;
        if ($userPid > 0) {
            if (!array_key_exists($userPid, $cache)) {
                $row = $wpdb->get_row($wpdb->prepare('SELECT wp_user_pid, user_id FROM `' . $this->prefix() . 'users` WHERE pid = %d', $userPid));
                $user = $row && (int)$row->wp_user_pid ? get_user_by('id', (int)$row->wp_user_pid) : null;
                if (!$user && $row && $row->user_id !== '') {
                    $user = get_user_by('login', $row->user_id);
                }
                $cache[$userPid] = $user ?: null;
            }
            return $cache[$userPid];
        }
        $userId = (string)$userId;
        return ($userId !== '' && $userId !== '0') ? (get_user_by('login', $userId) ?: null) : null;
    }

    private function summarize($board, $item)
    {
        $me = self::userPid();
        $readable = $this->viewable($board, $item) && $this->secretOpen($board, $item);
        $html = $readable ? $this->contentHtml($item) : '';
        $wpUser = $this->wpUserOf($item->user_pid, $item->user_id);
        $names = $this->categoryNames($board);
        $cat = array_search((string)$item->category1, $names, true);
        $out = $this->summary([
            'document_srl' => $this->num($board, $item->pid),
            'title' => BoardMoa_Html::text($item->title),
            'author' => BoardMoa_Html::text($item->user_name),
            'author_image' => $wpUser ? BoardMoa_Api::avatar($wpUser->ID) : null,
            'author_srl' => $wpUser ? (int)$wpUser->ID : 0,
            'is_mine' => $me && (int)$item->user_pid === $me,
            'regdate' => BoardMoa_Html::iso($item->reg_date),
            'last_update' => BoardMoa_Html::iso($item->modify_date),
            'category_srl' => $cat === false ? 0 : $cat + 1,
            'comment_count' => (int)$item->comment_count,
            'read_count' => (int)$item->hit,
            'vote_count' => (int)$item->vote_good_count,
            'is_notice' => (bool)(int)$item->is_notice,
            'is_secret' => (bool)(int)$item->is_secret,
            'has_files' => (int)$item->file_count > 0,
            'thumbnail' => $readable && $item->image_path !== '' ? BoardMoa_Html::absolute($item->image_path) : ($readable ? BoardMoa_Html::firstImage($html) : null),
            'summary' => $readable ? BoardMoa_Html::summary($html) : '',
        ]);
        if ((int)$item->depth > 0 && !(int)$item->is_notice) {
            $out['reply_depth'] = (int)$item->depth;
        }
        return $out;
    }

    private function findItem($board, $srl)
    {
        global $wpdb;
        $pid = $this->pid($board, $srl);
        $table = $this->table($board);
        $item = $pid ? $wpdb->get_row($wpdb->prepare("SELECT * FROM `$table` WHERE pid = %d", $pid)) : null;
        if (!$item) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        return $item;
    }

    private function item($board, $srl)
    {
        $item = $this->findItem($board, $srl);
        if (!$this->viewable($board, $item)) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        return $item;
    }

    /** 비밀글을 비밀번호로 열기 (웹 view.php 와 같다: 글 비밀번호, 답글이면 원글 비밀번호도) */
    private function openState($board, $item, $password)
    {
        global $wpdb;
        $open = $this->secretOpen($board, $item, $password);
        if (!$open && $password !== '' && (int)$item->depth > 0) {
            $parent = $wpdb->get_var($wpdb->prepare('SELECT passwd FROM `' . $this->table($board) . '` WHERE pid = %d', (int)$item->gid));
            $open = $parent && mbw_check_password($password, $parent);
        }
        return $open;
    }

    /** 답글을 쓸 수 있는가: 웹 본문의 [답글] 단추(스킨 view.php: reply_level, 공지 아님). 처리기도 reply_level 로 한 번 더 확인한다 */
    private function canReply($board, $item)
    {
        return $this->allows($this->row($board)->reply_level) && !(int)$item->is_notice;
    }

    /** 웹 본문 화면의 단추와 같은 판단 (스킨의 view.php): 고치기 = 자기 글 또는 modify_level, 지우기 = 자기 글 또는 delete_level */
    private function manageButtons($board, $item)
    {
        $row = $this->row($board);
        $me = self::userPid();
        $mine = $me && $me === (int)$item->user_pid;
        $loggedIn = mbw_is_login();
        $guestPost = !(int)$item->user_pid;
        return [
            'edit' => $loggedIn && ($mine || $this->allows($row->modify_level)),
            'delete' => $loggedIn && ($mine || $this->allows($row->delete_level)),
            // 비회원 글: 비회원에게 비밀번호로 고치기·지우기 (웹은 비밀번호를 물어 처리기가 확인한다)
            'password' => !$loggedIn && $guestPost && (string)$item->passwd !== '' && !$this->allows($row->delete_level),
        ];
    }

    public function document($board, $srl)
    {
        global $wpdb;
        $item = $this->item($board, $srl);
        $grant = $this->grant($board);
        $password = (string)BoardMoa_Api::param('password', '');
        $open = $this->openState($board, $item, $password);
        if (!$open && $password !== '') {
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        $url = add_query_arg('vid', (int)$item->pid, get_permalink((int)$board['page']));
        $buttons = $this->manageButtons($board, $item);
        if (!$open) {
            return $this->detail($this->summarize($board, $item), [
                'permanent_url' => $url, 'password_view' => $item->passwd !== '', 'password_edit' => $buttons['password'], 'board' => $this->info($board, $grant),
            ]);
        }
        // 조회수: 앱 접속(X-BoardHub-Session)별로 한 번 (댓글 뒤 다시 읽기·새로고침으로 오르지 않게, 다른 모듈과 같다)
        if (BoardMoa_Store::firstView('mb:' . $board['ref'] . ':' . (int)$item->pid)) {
            $wpdb->query($wpdb->prepare('UPDATE `' . $this->table($board) . '` SET hit = hit + 1 WHERE pid = %d', (int)$item->pid));
            $item->hit = (int)$item->hit + 1;
        }
        $summary = $this->summarize($board, $item);
        $summary['summary'] = BoardMoa_Html::summary($this->contentHtml($item));
        // 비밀번호로 연 이번 요청에서는 고치기·지우기 권한을 주지 않는다 (앱이 매번 비밀번호를 보낸다)
        return $this->detail($summary, [
            // 태그: 웹 글 화면(스킨 view 모델의 fn_tag)처럼 본문 끝에
            'content_html' => BoardMoa_Html::content($this->contentHtml($item)) . $this->tags($board, $item),
            'files' => $this->files($board, $item, $srl),
            'permanent_url' => $url,
            'board' => $this->info($board, $grant),
            'can_comment' => $grant['write_comment'],
            // 비밀번호로 연 비밀글: 댓글을 쓸 때 그 비밀번호를 document_password 로 같이 보낸다
            'comment_document_password' => $password !== '' && !$this->secretOpen($board, $item) && $grant['write_comment'] && (bool)$this->row($board)->use_comment,
            'can_reply' => $this->canReply($board, $item),
            'reply_title' => '[re]' . (string)$item->title,
            'reply_secret' => (bool)(int)$item->is_secret,
            'can_edit' => $buttons['edit'],
            'can_delete' => $buttons['delete'],
            'password_edit' => $buttons['password'],
            'actions' => $this->actions($board, $item),
            'comments' => $this->row($board)->use_comment ? $this->commentPage($board, $item) : self::emptyComments(),
        ]);
    }

    /** 글의 태그 (스킨 글 보기 모델에 태그 칸이 있을 때, 웹처럼 쉼표로 나눈 것) */
    private function tags($board, $item)
    {
        $shown = false;
        foreach ($this->model($board, 'view') as $field) {
            if (isset($field['field']) && $field['field'] === 'fn_tag') {
                $shown = mbw_check_item($field);
                break;
            }
        }
        $raw = isset($item->tag) ? trim(html_entity_decode((string)$item->tag, ENT_QUOTES, 'UTF-8')) : '';
        return ($shown && $raw !== '') ? self::tagsHtml(explode(',', $raw)) : '';
    }

    // ---- 첨부 파일 (웹 글 화면의 '첨부파일': 파일 표의 내려받기 파일 is_download = 1)

    private function filesTable()
    {
        global $mb_admin_tables;
        return !empty($mb_admin_tables['files']) ? (string)$mb_admin_tables['files'] : $this->prefix() . 'files';
    }

    private function fileRows($board, $item)
    {
        global $wpdb;
        return (array)$wpdb->get_results($wpdb->prepare('SELECT * FROM `' . $this->filesTable() . '` WHERE table_name = %s AND board_pid = %d AND is_download = 1 ORDER BY file_sequence ASC',
            $this->table($board), (int)$item->pid));
    }

    /** files: KBoard 와 같은 꼴. 내려받기는 file 로 (웹 board_action=file_download 와 같은 처리) */
    private function files($board, $item, $srl)
    {
        $out = [];
        foreach ($this->fileRows($board, $item) as $f) {
            $num = BoardMoa_Store::num('mbf:' . $board['ref'] . ':' . (int)$f->pid);
            $image = (bool)preg_match('/\.(jpe?g|png|gif|webp)$/i', (string)$f->file_name);
            $out[] = [
                'file_srl' => $num,
                'name' => (string)$f->file_name,
                'size' => (int)$f->file_size,
                'is_image' => $image,
                'image_url' => $image ? BoardMoa_Html::absolute(mbw_get_image_url('url', (string)$f->file_path)) : null,
                'download' => ['r' => 'file', 'mid' => $board['mid'], 'document_srl' => (int)$srl, 'file_srl' => $num],
            ];
        }
        return $out;
    }

    /**
     * 내려받기: 글을 읽을 수 있어야 하고(비밀글은 비밀번호), 웹의 내려받기 단추와 같은 망보드 처리(mb_board mode=file board_action=file_download:
     * 레벨 확인·내려받기 수·필터 mf_file_download_data)를 실행한 뒤, 웹 스크립트처럼 망보드 파일 주소(?mb_ext=file&type=download)로 넘긴다
     */
    public function file($board)
    {
        $srl = BoardMoa_Api::intParam('document_srl');
        $item = $this->writable($board, $srl);
        $ref = BoardMoa_Store::ref(BoardMoa_Api::intParam('file_srl'));
        $prefix = 'mbf:' . $board['ref'] . ':';
        $pid = ($ref && strpos($ref, $prefix) === 0) ? (int)substr($ref, strlen($prefix)) : 0;
        $row = null;
        foreach ($this->fileRows($board, $item) as $f) {
            if ((int)$f->pid === $pid) {
                $row = $f;
            }
        }
        if (!$row) {
            throw new BoardMoa_Error(404, 'not_found', '없는 파일입니다.');
        }
        $result = $this->run($board, 'mb_board', ['mode' => 'file', 'board_action' => 'file_download', 'file_pid' => (int)$row->pid, 'file_name' => (string)$row->file_name], 'not_permitted');
        $path = isset($result['data']['file_path']) ? (string)$result['data']['file_path'] : '';
        if ($path === '') {
            throw new BoardMoa_Error(404, 'not_found', '없는 파일입니다.');
        }
        $url = mbw_get_image_url();
        $url .= (strpos($url, '?') === false ? '?' : '&') . 'path=' . $path . '&file_name=' . rawurlencode((string)$row->file_name) . '&type=download';
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        status_header(302);
        header('Cache-Control: no-store, private');
        header('Location: ' . $url);
        return null;
    }

    /** 웹 글쓰기 양식의 파일 칸 (스킨 write 모델의 type file, 이 회원 레벨에 보이는 것) 수 */
    private function fileSlots($board)
    {
        $n = 0;
        foreach ($this->model($board, 'write') as $field) {
            if (isset($field['type']) && $field['type'] === 'file' && mbw_check_item($field)) {
                $n++;
            }
        }
        return $n;
    }

    /**
     * 파일을 붙일 수 있는가 (기능 file_upload): 쓰기 레벨이 되고 웹 글쓰기 양식에 파일 칸이 있을 때. 칸 수만큼(고치는 글은 이미 있는 첨부를 뺀 만큼).
     * 형식은 망보드의 첨부 형식($mb_board_upload_files), 크기는 설정 upload_file_size(MB)
     */
    private function attachInfo($board, $item)
    {
        global $mb_board_upload_files;
        $slots = $this->fileSlots($board);
        if (!$slots || !$this->allows($this->row($board)->write_level) || !function_exists('mbw_file_upload')) {
            return self::noFiles();
        }
        $free = max(0, $slots - ($item ? count($this->fileRows($board, $item)) : 0));
        $size = (float)mbw_get_option('upload_file_size');
        return ['allowed' => $free > 0, 'max_file_size' => $size > 0 ? (int)($size * 1024 * 1024) : null, 'max_count' => $free,
            'extensions' => $mb_board_upload_files ? array_values(array_map('strtolower', (array)$mb_board_upload_files)) : null];
    }

    /** 앱 files[] → 웹 양식의 파일 칸처럼 $_FILES (file1, file2 …) */
    private function attachFiles($board, $item, array $files)
    {
        if (!$files) {
            return [];
        }
        $info = $this->attachInfo($board, $item);
        if ($info['max_count'] === null) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 파일을 올릴 수 없습니다.');
        }
        if (count($files) > (int)$info['max_count']) {
            throw new BoardMoa_Error(400, 'upload_failed', '첨부할 수 있는 파일 수를 넘었습니다.');
        }
        $out = [];
        foreach (array_values($files) as $i => $file) {
            $out['file' . ($i + 1)] = $file;
        }
        return $out;
    }

    /** 글 화면 주소 (회원 전용 사이트 확인을 조회수보다 먼저 하려고) */
    public function documentUrl($board, $srl)
    {
        $pid = $this->pid($board, $srl);
        return $pid ? add_query_arg('vid', $pid, get_permalink((int)$board['page'])) : null;
    }

    /** 추천·비추천 (게시판 설정 use_board_vote_good·bad). 망보드는 회원만, 한 사람이 한 번 (쿠키 표 mb_board_vote) */
    private function actions($board, $item)
    {
        global $wpdb;
        $row = $this->row($board);
        $good = (int)$row->use_board_vote_good === 1;
        $bad = (int)$row->use_board_vote_bad === 1;
        if (!$good && !$bad) {
            return null;
        }
        $my = 0;
        if (mbw_is_login()) {
            $names = $wpdb->get_col($wpdb->prepare('SELECT cookie_name FROM `' . $this->prefix() . "cookies` WHERE user_pid = %d AND board_name = %s AND cookie_type = 'mb_board_vote' AND cookie_value = %s",
                self::userPid(), (string)$board['ref'], (string)(int)$item->pid));
            $my = in_array('good_pid', (array)$names, true) ? 1 : (in_array('bad_pid', (array)$names, true) ? -1 : 0);
        }
        return [
            'vote_up' => ['enabled' => $good, 'count' => (int)$item->vote_good_count, 'public' => false],
            'vote_down' => ['enabled' => $bad, 'count' => (int)$item->vote_bad_count, 'public' => false],
            'my_vote' => $my,
            'can_cancel_vote' => false,
            'is_mine' => self::userPid() && self::userPid() === (int)$item->user_pid,
            'can_scrap' => false,
            'can_declare' => false,
        ];
    }

    public function comments($board, $srl)
    {
        $item = $this->item($board, $srl);
        if (!$this->openState($board, $item, (string)BoardMoa_Api::param('password', ''))) {
            throw BoardMoa_Api::denied('비밀글입니다.');
        }
        return $this->row($board)->use_comment ? $this->commentPage($board, $item) : self::emptyComments();
    }

    private function commentPage($board, $item)
    {
        global $wpdb;
        $row = $this->row($board);
        $table = $this->table($board, true);
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM `$table` WHERE parent_pid = %d ORDER BY gid ASC, reply ASC", (int)$item->pid));
        $me = self::userPid();
        $loggedIn = mbw_is_login();
        // 웹 댓글 목록(api/mb-comment.php)의 단추와 같은 판단: 댓글 레벨이 되면 — 비회원 댓글은 비회원에게 비밀번호로, 아니면 자기 댓글이나 레벨
        $commentAllowed = $this->allows($row->comment_level);
        $items = [];
        foreach ((array)$rows as $c) {
            $secret = (bool)(int)$c->is_secret;
            $open = !$secret || $this->secretOpen($board, (object)['is_secret' => 1, 'user_pid' => $c->user_pid, 'parent_user_pid' => $c->parent_user_pid, 'passwd' => '']);
            $guestComment = !(int)$c->user_pid;
            $mine = $me && (int)$c->user_pid === $me;
            $buttons = $open && $commentAllowed;
            $wpUser = $this->wpUserOf($c->user_pid);
            $reply = (int)$c->gid && (int)$c->gid !== (int)$c->pid;
            $items[] = $this->commentItem([
                'comment_srl' => $this->commentNum($board, $c->pid),
                'parent_srl' => $reply ? $this->commentNum($board, $c->gid) : 0,
                'depth' => $reply ? 1 : 0,
                'author' => BoardMoa_Html::text($c->user_name),
                'author_image' => $wpUser ? BoardMoa_Api::avatar($wpUser->ID) : null,
                'author_srl' => $wpUser ? (int)$wpUser->ID : 0,
                'is_mine' => $mine,
                'regdate' => BoardMoa_Html::iso($c->reg_date),
                'is_secret' => $secret,
                'content_html' => $open ? BoardMoa_Html::content(nl2br(esc_html(html_entity_decode((string)$c->content, ENT_QUOTES, 'UTF-8')), false)) : null,
                'vote_count' => (int)$c->vote_good_count,
                'can_delete' => $buttons && $loggedIn && ($mine || $this->allows($row->delete_level)),
                'can_edit' => $buttons && $loggedIn && ($mine || $this->allows($row->modify_level)),
                'password_edit' => $buttons && !$loggedIn && $guestComment && (string)$c->passwd !== '',
                // 댓글 추천 (기능 comment_vote): 웹 댓글 목록처럼 원댓글에만, 잠긴 비밀 댓글은 없음
                'vote' => ($open && !$reply) ? $this->commentVoteState($board, $c) : null,
            ]);
        }
        return ['items' => $items, 'page' => 1, 'total_pages' => 1, 'total_count' => count($items)];
    }

    /** 망보드 댓글 추천 (게시판 설정 use_comment_vote_good·bad). 회원만 한 번 (쿠키 표 mb_comment_vote), 취소 없음 */
    private function commentVoteState($board, $c)
    {
        global $wpdb;
        $row = $this->row($board);
        $good = (int)$row->use_comment_vote_good === 1;
        $bad = (int)$row->use_comment_vote_bad === 1;
        if (!$good && !$bad) {
            return null;
        }
        $my = 0;
        if (mbw_is_login()) {
            $names = $wpdb->get_col($wpdb->prepare('SELECT cookie_name FROM `' . $this->prefix() . "cookies` WHERE user_pid = %d AND board_name = %s AND cookie_type = 'mb_comment_vote' AND cookie_value = %s",
                self::userPid(), (string)$board['ref'], (string)(int)$c->pid));
            $my = in_array('good_pid', (array)$names, true) ? 1 : (in_array('bad_pid', (array)$names, true) ? -1 : 0);
        }
        return [
            'up' => ['enabled' => $good, 'count' => (int)$c->vote_good_count],
            'down' => ['enabled' => $bad, 'count' => (int)(isset($c->vote_bad_count) ? $c->vote_bad_count : 0)],
            'my_vote' => $my,
            'can_cancel' => false,
        ];
    }

    /** 댓글 추천: 웹 댓글 단추와 같은 망보드 처리기(mb_comment board_action=vote_good·vote_bad) */
    public function commentVote($board, $commentSrl)
    {
        $c = $this->commentRow($board, $commentSrl);
        $documentPassword = (string)BoardMoa_Api::param('document_password', '');
        $item = $this->writable($board, $this->num($board, $c->parent_pid), $documentPassword !== '' ? $documentPassword : null);
        $row = $this->row($board);
        $reply = (int)$c->gid && (int)$c->gid !== (int)$c->pid;
        $open = !(int)$c->is_secret || $this->secretOpen($board, (object)['is_secret' => 1, 'user_pid' => $c->user_pid, 'parent_user_pid' => $c->parent_user_pid, 'passwd' => '']);
        $state = (int)$row->use_comment === 1 && !$reply && $open ? $this->commentVoteState($board, $c) : null;
        if (BoardMoa_Api::boolParam('cancel')) {
            throw new BoardMoa_Error(400, 'vote_failed', '추천은 취소할 수 없습니다.');
        }
        $down = BoardMoa_Api::intParam('point', 1) < 0;
        if (!$state || !$state[$down ? 'down' : 'up']['enabled']) {
            throw new BoardMoa_Error(403, 'not_permitted', '이 게시판은 추천을 쓰지 않습니다.');
        }
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $this->run($board, 'mb_comment', ['mode' => 'comment', 'board_action' => $down ? 'vote_bad' : 'vote_good', 'parent_pid' => (int)$item->pid, 'comment_pid' => (int)$c->pid], 'vote_failed');
        return $this->commentVoteState($board, $this->commentRow($board, $commentSrl));
    }

    public function boardOfDocument($srl)
    {
        $ref = BoardMoa_Store::ref($srl);
        if (!$ref || !preg_match('/^mb:([A-Za-z0-9_]+):\d+$/', $ref, $m)) {
            return null;
        }
        foreach ($this->boards() as $b) {
            if ($b['ref'] === $m[1]) {
                return $b;
            }
        }
        return null;
    }

    public function locate($url)
    {
        $postId = url_to_postid($url);
        if (!$postId) {
            return null;
        }
        parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
        foreach ($this->boards() as $b) {
            if ((int)$b['page'] === (int)$postId) {
                $out = ['mid' => $b['mid']];
                $pid = !empty($query['vid']) ? (int)$query['vid'] : (!empty($query['board_pid']) && (isset($query['mode']) && $query['mode'] === 'view') ? (int)$query['board_pid'] : 0);
                if ($pid > 0) {
                    // 번호 표에는 실제로 있는 글만 넣는다 (아무 번호나 보내 표를 키우지 못하게)
                    global $wpdb;
                    $srl = BoardMoa_Store::find('mb:' . $b['ref'] . ':' . $pid);
                    if (!$srl && $wpdb->get_var($wpdb->prepare('SELECT pid FROM `' . $this->table($b) . '` WHERE pid = %d', $pid))) {
                        $srl = $this->num($b, $pid);
                    }
                    if ($srl) {
                        $out['document_srl'] = $srl;
                    }
                }
                return $out;
            }
        }
        return null;
    }

    // ---- 쓰기: 망보드 처리기를 웹 요청처럼 실행한다

    /**
     * 웹 화면이 admin-ajax.php?action=mb_board(·mb_comment) 로 보내는 값($fields)으로 망보드 처리기를 실행하고 결과(state·code·message·data)를 돌려준다.
     * 망보드는 요청 하나의 상태를 전역(MStore·추적 목록)에 담고, 요청 처음(플러그인 불러올 때·init)에 그 요청 값으로 채운다.
     * 앱 요청에서는 그때 앱 주소의 값으로 채워졌으므로, 새 MStore 로 같은 순서(mbw_set_params → 회원 → mbw_is_permission_level)를 밟은 뒤
     * 처리기(mbw_api_callback)를 부른다. 회원은 init 때 망보드가 정한 그대로(이번 요청의 토큰 회원)를 넘겨받는다.
     */
    private function run($board, $action, array $fields, $failCode = 'blocked', array $files = [], callable $handler = null)
    {
        global $mstore, $mdb, $mb_options, $mb_languages, $mb_trace, $mb_vars, $mb_check_set_param, $mb_request_mode, $mb_error_message,
               $mb_board_table_name, $mb_comment_table_name;
        $saved = [
            'mstore' => $mstore, 'trace' => $mb_trace, 'vars' => $mb_vars, 'checked' => $mb_check_set_param, 'mode' => $mb_request_mode,
            'errors' => $mb_error_message, 'board_table' => $mb_board_table_name, 'comment_table' => $mb_comment_table_name,
            'get' => $_GET, 'post' => $_POST, 'request' => $_REQUEST, 'files' => $_FILES, 'referer' => isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null,
        ];
        $old = $mstore;
        $doingAjax = function () {
            return true;
        };
        try {
            $fresh = new MStore($mdb, $mb_options);
            $fresh->set_messages($mb_languages);
            // 회원: init 때 망보드가 이번 요청의 회원으로 정한 값
            $fresh->user = $old->user;
            $fresh->user_login = $old->user_login;
            $mstore = $fresh;
            $once = ['mbw_set_params', 'mbw_set_board_params', 'mbw_set_shortcode_where', 'mbw_set_shortcode_options', 'mbw_init_options'];
            $mb_trace = array_values(array_filter((array)$mb_trace, function ($name) use ($once) {
                return !in_array($name, $once, true);
            }));
            if (is_array($mb_vars)) {
                unset($mb_vars['shortcode_args']);
            }
            $mb_check_set_param = false;
            $mb_error_message = [];
            $mb_request_mode = 'API';
            $mb_board_table_name = '';
            $mb_comment_table_name = '';
            // 망보드의 웹 처리기는 플러그인을 불러올 때(워드프레스가 따옴표를 붙이기 전) 값을 읽는다: 붙이지 않은 값
            $_GET = ['action' => $action];
            $_POST = array_merge(['board_name' => (string)$board['ref']], $fields);
            $_REQUEST = array_merge($_GET, $_POST);
            $_FILES = $files;
            $_SERVER['HTTP_REFERER'] = get_permalink((int)$board['page']);
            mbw_set_params();
            mbw_is_permission_level();
            if (mbw_get_result_data('state') !== 'error') {
                // 웹 양식이 숨은 칸으로 보내는 확인 값 (mbw_create_nonce('form'))
                if (preg_match_all('/name="(mb_nonce_value|mb_nonce_time|wp_nonce_value)"[^>]*value="([^"]*)"/', (string)mbw_create_nonce('form'), $m, PREG_SET_ORDER)) {
                    foreach ($m as $pair) {
                        $value = html_entity_decode($pair[2], ENT_QUOTES, 'UTF-8');
                        mbw_set_param($pair[1], $value);
                        $_POST[$pair[1]] = $value;
                        $_REQUEST[$pair[1]] = $value;
                    }
                }
                add_filter('wp_doing_ajax', $doingAjax, PHP_INT_MAX);
                $run = BoardMoa_Run::call($handler ?: function () {
                    mbw_api_callback();
                });
                remove_filter('wp_doing_ajax', $doingAjax, PHP_INT_MAX);
                $result = json_decode(trim((string)$run['output']), true);
                if (!is_array($result)) {
                    $message = BoardMoa_Run::messageOf($run['output']);
                    $result = ['state' => 'error', 'code' => '0', 'message' => $message !== '' ? $message : (string)$run['died']];
                }
            } else {
                $result = mbw_get_result_array();
            }
            $result['params'] = $mstore->params;
        } finally {
            remove_filter('wp_doing_ajax', $doingAjax, PHP_INT_MAX);
            $mstore = $saved['mstore'];
            $mb_trace = $saved['trace'];
            $mb_vars = $saved['vars'];
            $mb_check_set_param = $saved['checked'];
            $mb_request_mode = $saved['mode'];
            $mb_error_message = $saved['errors'];
            $mb_board_table_name = $saved['board_table'];
            $mb_comment_table_name = $saved['comment_table'];
            $_GET = $saved['get'];
            $_POST = $saved['post'];
            $_REQUEST = $saved['request'];
            $_FILES = $saved['files'];
            if ($saved['referer'] === null) {
                unset($_SERVER['HTTP_REFERER']);
            } else {
                $_SERVER['HTTP_REFERER'] = $saved['referer'];
            }
        }
        if (isset($result['state']) && $result['state'] === 'success') {
            return $result;
        }
        throw self::failure($result, $failCode);
    }

    /** 망보드 오류(코드·문구)를 앱 오류로. 문구는 망보드가 만든 것(사이트 언어)을 그대로 */
    private static function failure(array $result, $failCode)
    {
        $code = (string)(isset($result['code']) ? $result['code'] : '');
        $message = trim(html_entity_decode(wp_strip_all_tags(str_replace(['<br>', '<br/>', '<br />', '</div>'], ' ', (string)(isset($result['message']) ? $result['message'] : ''))), ENT_QUOTES, 'UTF-8'));
        $message = trim(preg_replace('/\s+/u', ' ', $message));
        $target = (string)(isset($result['target_name']) ? $result['target_name'] : '');
        if ($code === '1103') {
            return new BoardMoa_Error(401, 'login_required', $message !== '' ? $message : '로그인이 필요합니다.', $message !== '');
        }
        if ($code === '1102' || $code === '1101') {
            return new BoardMoa_Error(is_user_logged_in() ? 403 : 401, $code === '1101' ? 'login_required' : 'not_permitted', $message !== '' ? $message : '권한이 없습니다.', $message !== '');
        }
        if ($code === '1206' && $target === 'passwd') {
            return new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        if ($target === 'kcaptcha_img') {
            $widget = self::$captchaRetry;
            return new BoardMoa_Error(403, 'captcha_required', $widget ? '자동 입력 방지 확인이 필요합니다.' : '이 게시판은 웹에서 자동 입력 방지 확인을 해야 글을 쓸 수 있습니다.', false, ['captcha' => $widget]);
        }
        if ($code === '1201' && ($target === 'passwd' || $target === 'user_name')) {
            return new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력해 주세요.');
        }
        if ($code === '1201') {
            return new BoardMoa_Error(400, 'missing_content', $message !== '' ? $message : '제목과 내용을 입력해 주세요.', $message !== '');
        }
        return new BoardMoa_Error(400, $failCode, $message !== '' ? $message : '처리하지 못했습니다.', $message !== '');
    }

    /** 쓰기 앞단: 목록·보기를 볼 수 있는 게시판의 글 (findItem 은 없는 글이면 404) */
    private function writable($board, $srl, $password = null)
    {
        $item = $this->item($board, $srl);
        $password = $password !== null ? $password : (string)BoardMoa_Api::param('password', '');
        if (!$this->openState($board, $item, $password)) {
            // 비밀번호를 보냈는데 틀렸으면 wrong_password (비밀번호 시도 제한이 센다)
            throw $password !== '' ? new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.') : BoardMoa_Api::denied('비밀글입니다.');
        }
        return $item;
    }

    /** 글쓰기 칸 편집기: 글자(textarea, editor_type N)면 일반 글자로, 아니면 HTML 로 보낸다 (웹 양식의 data_type 과 같다) */
    /**
     * 사진: 웹 글쓰기 편집기의 사진 올리기(includes/mb-uploader.php)와 같다 — 글자 편집기(N)가 아닌 게시판에서, 쓰기 레벨이면(망보드가 올리기를 쓰기 레벨로 확인한다).
     * 크기 한도는 망보드 설정 upload_file_size(MB), 형식은 편집기 그림 형식($mb_image_upload_files)에 jpg 가 있을 때
     */
    private function uploadInfo($board)
    {
        global $mb_image_upload_files;
        $row = $this->row($board);
        $allowed = (string)$row->editor_type !== 'N' && $this->allows($row->write_level) && in_array('jpg', (array)$mb_image_upload_files, true) && function_exists('mbw_file_upload');
        $size = (float)mbw_get_option('upload_file_size');
        return ['allowed' => $allowed, 'max_file_size' => ($allowed && $size > 0) ? (int)($size * 1024 * 1024) : null, 'max_total_size' => null];
    }

    /**
     * 앱 사진을 편집기 사진처럼 올리고 본문 끝에 붙일 그림 태그를 돌려준다. 웹 편집기와 같은 처리(mbw_check_api_file('editor') → mbw_file_upload type editor,
     * 망보드 요청 시작 순서·확인 값·쓰기 레벨 확인은 run 이 웹 올리기 요청 mb_uploader 처럼 밟는다)
     */
    private function uploadPhotos($board, array $photos)
    {
        if (!$photos) {
            return '';
        }
        if (!$this->uploadInfo($board)['allowed']) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        $style = self::photoStyle();
        $html = '';
        foreach ($photos as $photo) {
            $result = $this->run($board, 'mb_uploader', ['mode' => 'basic'], 'upload_failed', ['upload' => $photo], function () {
                if (!mbw_check_api_file('editor')) {
                    echo wp_json_encode(array_merge(['state' => 'error'], (array)mbw_get_result_array()));
                    return;
                }
                $upload = mbw_file_upload(['board_name' => 'N', 'table_name' => 'N', 'board_pid' => '0', 'type' => 'editor']);
                if (empty($upload['path']) || mbw_get_result_data('state') === 'error') {
                    echo wp_json_encode(array_merge((array)mbw_get_result_array(), ['state' => 'error']));
                    return;
                }
                echo wp_json_encode(['state' => 'success', 'url' => mbw_get_image_url('path', $upload['path'])]);
            });
            $html .= '<p><img src="' . esc_url((string)$result['url']) . '" alt="" style="' . esc_attr($style) . '"></p>';
        }
        return $html;
    }

    private function contentFields($board, $html)
    {
        if ((string)$this->row($board)->editor_type === 'N') {
            return ['content' => self::htmlToText($html), 'data_type' => 'text'];
        }
        return ['content' => $html, 'data_type' => 'html'];
    }

    /** 앱의 HTML(일반 글자를 바꾼 것·꾸밈 편집기) → 글자: 줄바꿈은 살린다 */
    private static function htmlToText($html)
    {
        $html = str_replace(["\r\n", "\r"], "\n", (string)$html);
        $html = preg_replace('#<\s*br\s*/?>[ \t]*\n?#i', "\n", $html);
        $html = preg_replace('#</\s*(p|div|li|h[1-6]|blockquote)\s*>[ \t]*\n?#i', "\n\n", $html);
        $text = html_entity_decode(wp_strip_all_tags($html, false), ENT_QUOTES, 'UTF-8');
        $text = str_replace("\xC2\xA0", ' ', $text);
        return trim(preg_replace("/\n{3,}/", "\n\n", str_replace(["\r\n", "\r"], "\n", $text)));
    }

    private function guestFields(array &$fields)
    {
        if (is_user_logged_in()) {
            return;
        }
        $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
        $password = (string)BoardMoa_Api::param('password', '');
        if ($nick === '' || $password === '') {
            throw new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력해 주세요.');
        }
        $fields['user_name'] = $nick;
        $fields['passwd'] = $password;
    }

    public function write($board)
    {
        $row = $this->row($board);
        // 답글 (parent_srl): 웹의 [답글] 과 같은 조건, 원글을 읽을 수 있어야 한다
        $parent = null;
        if (BoardMoa_Api::intParam('parent_srl')) {
            $parent = $this->item($board, BoardMoa_Api::intParam('parent_srl'));
            if (!$this->openState($board, $parent, '') || !$this->canReply($board, $parent)) {
                throw BoardMoa_Api::denied();
            }
        } elseif (!$this->grant($board)['write_document']) {
            throw BoardMoa_Api::denied();
        }
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $html = BoardMoa_Html::contentParam();
        if ($title === '' || trim(wp_strip_all_tags($html)) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $html .= $this->uploadPhotos($board, self::photos());
        $fields = array_merge(['mode' => 'write', 'board_action' => 'write', 'title' => $title, 'parent_pid' => 0, 'parent_user_pid' => 0, 'calendar_date' => ''], $this->contentFields($board, $html));
        if ($parent) {
            // 웹 답글 양식이 원글에서 넣어 보내는 값 (처리기가 묶음·순서·깊이를 정하고 분류를 이어받는다)
            $fields = array_merge($fields, ['board_action' => 'reply', 'board_gid' => (int)$parent->gid, 'board_reply' => (int)$parent->reply, 'reply_depth' => (int)$parent->depth]);
        }
        $names = $this->categoryNames($board);
        $cat = BoardMoa_Api::intParam('category_srl');
        if ($cat && isset($names[$cat - 1])) {
            $fields['category1'] = $names[$cat - 1];
        }
        // 비밀글: 1 = 고를 수 있음, 2 = 늘 비밀글 (웹 양식의 체크 상자와 같다)
        if ((int)$row->use_secret === 2 || ((int)$row->use_secret === 1 && BoardMoa_Api::boolParam('is_secret'))) {
            $fields['is_secret'] = '1';
        }
        $this->guestFields($fields);
        $this->captchaFields($board, false, $fields);
        $files = $this->attachFiles($board, null, self::attachments());
        $result = $this->run($board, 'mb_board', $fields, $files ? 'upload_failed' : 'write_failed', $files);
        $pid = isset($result['data']['pid']) ? (int)$result['data']['pid'] : (int)(isset($result['params']['board_pid']) ? $result['params']['board_pid'] : 0);
        if (!$pid) {
            throw new BoardMoa_Error(400, 'write_failed', '글을 저장하지 못했습니다.');
        }
        return ['document_srl' => $this->num($board, $pid)];
    }

    /**
     * 고칠 수 있는 글: 웹의 고치기 단추·처리기와 같다 — 자기 글·고치기 레벨(회원), 비회원 글은 비회원이 비밀번호로.
     * 처리기(mbw_check_api_permission)가 한 번 더 확인한다.
     */
    private function editable($board, $srl, $delete)
    {
        $item = $this->findItem($board, $srl);
        if (!$this->viewable($board, $item)) {
            throw is_user_logged_in() ? BoardMoa_Api::denied() : new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $buttons = $this->manageButtons($board, $item);
        if ($delete ? $buttons['delete'] : $buttons['edit']) {
            return $item;
        }
        if ($buttons['password']) {
            $password = (string)BoardMoa_Api::param('password', '');
            if ($password === '') {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            if (!mbw_check_password($password, (string)$item->passwd)) {
                throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
            }
            return $item;
        }
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        throw BoardMoa_Api::denied();
    }

    public function source($board, $srl)
    {
        $item = $this->editable($board, $srl, false);
        $names = $this->categoryNames($board);
        $cat = array_search((string)$item->category1, $names, true);
        return [
            'document_srl' => (int)$srl,
            'title' => BoardMoa_Html::text($item->title),
            'content' => $this->contentHtml($item),
            'base_url' => trailingslashit(home_url('/')),
            'manage' => null,
            'category_srl' => $cat === false ? 0 : $cat + 1,
            'extra_keys' => [],
            'extra_values' => (object)[],
            'board' => $this->info($board, $this->grant($board)),
            'upload' => $this->uploadInfo($board) + ['files' => $this->attachInfo($board, $item)],
        ];
    }

    public function update($board, $srl)
    {
        $item = $this->editable($board, $srl, false);
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $html = (string)BoardMoa_Api::param('content', '');
        if ($title === '' || trim(wp_strip_all_tags($html)) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $html .= $this->uploadPhotos($board, self::photos());
        // 웹 고치기 양식처럼 원래 값(분류·비밀글·글쓴이 이름)을 같이 보낸다. 보내지 않으면 처리기가 비우거나 끈다
        $fields = array_merge(['mode' => 'write', 'board_action' => 'modify', 'board_pid' => (int)$item->pid, 'title' => $title,
            'parent_pid' => (int)$item->parent_pid, 'parent_user_pid' => (int)$item->parent_user_pid, 'category1' => (string)$item->category1], $this->contentFields($board, $html));
        if (BoardMoa_Api::param('category_srl') !== null) {
            $names = $this->categoryNames($board);
            $cat = BoardMoa_Api::intParam('category_srl');
            $fields['category1'] = ($cat && isset($names[$cat - 1])) ? $names[$cat - 1] : '';
        }
        if ((int)$item->is_secret) {
            $fields['is_secret'] = '1';
        }
        if (!(int)$item->user_pid) {
            $fields['user_name'] = (string)$item->user_name;
            if (!is_user_logged_in()) {
                $fields['passwd'] = (string)BoardMoa_Api::param('password', '');
            }
        }
        $files = $this->attachFiles($board, $item, self::attachments());
        $this->run($board, 'mb_board', $fields, $files ? 'upload_failed' : 'write_failed', $files);
        return ['document_srl' => (int)$srl];
    }

    public function delete($board, $srl)
    {
        $item = $this->editable($board, $srl, true);
        // 웹 본문 화면의 지우기: mode=view&board_action=delete&board_pid&passwd
        $this->run($board, 'mb_board', ['mode' => 'view', 'board_action' => 'delete', 'board_pid' => (int)$item->pid, 'passwd' => (string)BoardMoa_Api::param('password', '')]);
        return ['deleted' => true];
    }

    public function vote($board, $srl)
    {
        $item = $this->writable($board, $srl);
        if (BoardMoa_Api::boolParam('cancel')) {
            throw new BoardMoa_Error(400, 'vote_failed', '추천은 취소할 수 없습니다.');
        }
        $point = BoardMoa_Api::intParam('point', 1);
        $actions = $this->actions($board, $item);
        if (!$actions || !$actions[$point < 0 ? 'vote_down' : 'vote_up']['enabled']) {
            throw new BoardMoa_Error(403, 'not_permitted', '이 게시판은 추천을 쓰지 않습니다.');
        }
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $this->run($board, 'mb_board', ['mode' => 'view', 'board_action' => $point < 0 ? 'vote_bad' : 'vote_good', 'board_pid' => (int)$item->pid], 'vote_failed');
        return $this->actions($board, $this->findItem($board, $srl));
    }

    // ---- 댓글

    private function commentRow($board, $commentSrl)
    {
        global $wpdb;
        $ref = BoardMoa_Store::ref($commentSrl);
        $prefix = 'mbc:' . $board['ref'] . ':';
        $pid = ($ref && strpos($ref, $prefix) === 0) ? (int)substr($ref, strlen($prefix)) : 0;
        $c = $pid ? $wpdb->get_row($wpdb->prepare('SELECT * FROM `' . $this->table($board, true) . '` WHERE pid = %d', $pid)) : null;
        if (!$c) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        return $c;
    }

    public function commentWrite($board, $srl)
    {
        // 비밀번호로 연 비밀글 (기능 unlocked_comment): 글은 document_password 로 연다 (password 는 비회원 댓글의 비밀번호)
        $documentPassword = (string)BoardMoa_Api::param('document_password', '');
        $item = $this->writable($board, $srl, $documentPassword !== '' ? $documentPassword : null);
        $row = $this->row($board);
        if (!(int)$row->use_comment) {
            throw BoardMoa_Api::denied();
        }
        if (!$this->grant($board)['write_comment']) {
            if (!is_user_logged_in() && BoardMoa_Api::param('nick_name') === null && BoardMoa_Api::param('password') === null) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            throw BoardMoa_Api::denied();
        }
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        if ($text === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $fields = ['mode' => 'comment', 'board_action' => 'write', 'parent_pid' => (int)$item->pid, 'comment_pid' => '', 'content' => $text];
        // 비밀 댓글: 웹 댓글 양식의 비밀 칸과 같은 값 (처리기 mb-comment.php 가 is_secret 을 받는다)
        if (BoardMoa_Api::boolParam('is_secret')) {
            $fields['is_secret'] = '1';
        }
        $parent = BoardMoa_Api::intParam('parent_srl');
        if ($parent) {
            $p = $this->commentRow($board, $parent);
            if ((int)$p->parent_pid !== (int)$item->pid) {
                throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
            }
            $fields['board_action'] = 'reply';
            $fields['comment_pid'] = (int)$p->pid;
        }
        if (!is_user_logged_in()) {
            if (BoardMoa_Api::param('nick_name') === null && BoardMoa_Api::param('password') === null) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            $this->guestFields($fields);
        }
        $this->captchaFields($board, true, $fields);
        $result = $this->run($board, 'mb_comment', $fields, 'comment_failed');
        $pid = (int)(isset($result['params']['comment_pid']) ? $result['params']['comment_pid'] : 0);
        if (!$pid) {
            throw new BoardMoa_Error(400, 'comment_failed', '댓글을 쓰지 못했습니다.');
        }
        return ['comment_srl' => $this->commentNum($board, $pid), 'document_srl' => (int)$srl, 'pending' => false];
    }

    /** 댓글을 고치거나 지울 수 있는가: 웹 댓글 단추(api/mb-comment.php)와 같은 판단, 비회원 댓글은 비회원이 비밀번호로 */
    private function editableComment($board, $commentSrl, $delete)
    {
        $row = $this->row($board);
        $c = $this->commentRow($board, $commentSrl);
        $item = $this->findItem($board, $this->num($board, $c->parent_pid));
        // 웹은 글을 열어야 댓글 단추가 보인다 (비회원은 댓글 비밀번호로 확인하므로 글 비밀번호는 묻지 않는다).
        // 회원 자기 댓글은 비밀번호로 연 비밀글에 단 것이어도 고치고 지울 수 있다 (웹은 비밀번호를 넣은 접속에서 단추가 보인다)
        $me = self::userPid();
        $ownComment = $me && $me === (int)$c->user_pid;
        if (!$this->viewable($board, $item) || (is_user_logged_in() && !$ownComment && !$this->openState($board, $item, ''))) {
            throw BoardMoa_Api::denied();
        }
        if (!$this->allows($row->comment_level)) {
            throw BoardMoa_Api::denied();
        }
        if (mbw_is_login()) {
            if ($ownComment || $this->allows($delete ? $row->delete_level : $row->modify_level)) {
                return [$c, $item];
            }
            throw BoardMoa_Api::denied();
        }
        $password = (string)BoardMoa_Api::param('password', '');
        if ((int)$c->user_pid || (string)$c->passwd === '') {
            throw $password === '' ? new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.') : BoardMoa_Api::denied();
        }
        if ($password === '') {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!mbw_check_password($password, (string)$c->passwd)) {
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        return [$c, $item];
    }

    public function commentUpdate($board, $commentSrl)
    {
        list($c, $item) = $this->editableComment($board, $commentSrl, false);
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        if ($text === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $fields = ['mode' => 'comment', 'board_action' => 'modify', 'parent_pid' => (int)$item->pid, 'comment_pid' => (int)$c->pid, 'content' => $text];
        // 비밀 댓글은 그대로 (처리기는 is_secret 이 비면 공개로 바꾼다)
        if (!empty($c->is_secret)) {
            $fields['is_secret'] = '1';
        }
        if (!(int)$c->user_pid) {
            $fields['user_name'] = (string)$c->user_name;
            if (!is_user_logged_in()) {
                $fields['passwd'] = (string)BoardMoa_Api::param('password', '');
            }
        }
        $this->run($board, 'mb_comment', $fields, 'comment_failed');
        return ['comment_srl' => (int)$commentSrl, 'document_srl' => $this->num($board, $item->pid)];
    }

    public function commentDelete($board, $commentSrl)
    {
        list($c, $item) = $this->editableComment($board, $commentSrl, true);
        $this->run($board, 'mb_comment', ['mode' => 'comment', 'board_action' => 'delete', 'parent_pid' => (int)$item->pid, 'comment_pid' => (int)$c->pid,
            'passwd' => (string)BoardMoa_Api::param('password', ''), 'comment_size' => 0]);
        return ['deleted' => true];
    }
}
