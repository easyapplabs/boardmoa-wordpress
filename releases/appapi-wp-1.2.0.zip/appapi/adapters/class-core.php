<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 워드프레스 글·분류·페이지·댓글.
 *  - posts: 글 전체 (블로그 첫 화면·'글 페이지'), cat-<번호>: 분류 보관함, page-<번호>: 페이지(또는 메뉴에 걸린 글 하나)
 *  - 읽기: 공개 글은 누구나, 비공개(private) 글은 워드프레스의 read_post 권한(읽을 권한·글쓴이), 비밀번호 글은 비밀번호를 넣어야 본문
 *    (목록은 WP_Query 가 웹 보관함과 같은 기준으로 거른다)
 *  - 쓰기: 웹의 글쓰기(관리 화면)와 같은 권한 — edit_posts. 바로 공개할 권한(publish_posts)이 없으면 '검토 대기'로 들어간다
 *  - 댓글: wp-comments-post.php 와 같은 wp_handle_comment_submission (댓글 닫힘·로그인 필요·이름/메일·도배·중복·스팸 플러그인)
 */
class BoardMoa_Core extends BoardMoa_Adapter
{
    public function key()
    {
        return 'core';
    }

    public function available()
    {
        return true;
    }

    public function boards()
    {
        $boards = [];
        // '글 페이지'는 첫 화면을 정적 페이지로 정했을 때만 글 목록이다 (워드프레스와 같다)
        $postsPage = self::postsPage();
        $boards['posts'] = [
            'mid' => 'posts', 'adapter' => 'core', 'module' => 'board', 'ref' => 0,
            'title' => $postsPage ? BoardMoa_Html::text(get_the_title($postsPage)) : BoardMoa_Text::t('글'),
            'url' => $postsPage ? get_permalink($postsPage) : (get_option('show_on_front') === 'page' ? '' : home_url('/')),
        ];
        foreach (get_categories(['hide_empty' => false]) as $term) {
            $boards['cat-' . $term->term_id] = [
                'mid' => 'cat-' . $term->term_id, 'adapter' => 'core', 'module' => 'board', 'ref' => (int)$term->term_id,
                'title' => BoardMoa_Html::text($term->name), 'url' => get_category_link($term),
            ];
        }
        return $boards;
    }

    /** 글 목록 페이지 (설정 → 읽기: 첫 화면이 정적 페이지일 때만) */
    public static function postsPage()
    {
        return get_option('show_on_front') === 'page' ? (int)get_option('page_for_posts') : 0;
    }

    /** page-<번호> 로 열 수 있는 글 종류: 메뉴(fromMenuNode)와 같다. 그 밖의 글 종류(bbPress 토픽, KBoard 가 wp_posts 에 둔 kboard,
     * Elementor 서식 등)는 자기 어댑터의 권한 판단으로만 열고, page-<번호> 로는 없는 페이지 */
    const PAGE_TYPES = ['page', 'post'];

    /** page-<번호>: 페이지 또는 글 하나 (메뉴·링크에서) */
    public function pageBoard($mid)
    {
        if (!preg_match('/^page-(\d+)$/', (string)$mid, $m)) {
            return null;
        }
        $post = get_post((int)$m[1]);
        if (!$post || !in_array($post->post_type, self::PAGE_TYPES, true)) {
            return null;
        }
        return ['mid' => 'page-' . $post->ID, 'adapter' => 'core', 'module' => 'page', 'ref' => (int)$post->ID,
            'title' => BoardMoa_Html::text(get_the_title($post)), 'url' => get_permalink($post)];
    }

    public function fromMenuNode($node)
    {
        $type = isset($node['type']) ? $node['type'] : '';
        $object = isset($node['object']) ? $node['object'] : '';
        $id = isset($node['object_id']) ? (int)$node['object_id'] : 0;
        if ($type === 'taxonomy' && $object === 'category' && $id) {
            return ['mid' => 'cat-' . $id, 'expand' => null];
        }
        if ($type === 'post_type_archive' && $object === 'post') {
            return ['mid' => 'posts', 'expand' => null];
        }
        if ($type === 'post_type' && $id) {
            if ($id && $id === self::postsPage()) {
                return ['mid' => 'posts', 'expand' => null];
            }
            $post = get_post($id);
            if ($post && in_array($post->post_type, self::PAGE_TYPES, true)) {
                return ['mid' => 'page-' . $id, 'expand' => null];
            }
            return null;
        }
        if ($type === 'custom' && !empty($node['url'])) {
            $url = BoardMoa_Html::absolute($node['url']);
            if (strtolower((string)parse_url($url, PHP_URL_HOST)) !== strtolower((string)parse_url(home_url('/'), PHP_URL_HOST))) {
                return null;
            }
            $found = BoardMoa_Boards::locate($url);
            return $found && empty($found['document_srl']) ? ['mid' => $found['mid'], 'expand' => null] : null;
        }
        return null;
    }

    public function memberSearch($board, $userId)
    {
        return ['member_srl' => (string)(int)$userId];
    }

    /** 웹: 글쓴이 이름 → 글쓴이 보관함(/author/<이름>/, 분류와 상관없이 글 전체). 회원 정보 화면은 웹에 없다 */
    public function webNameMenu($board, $userId)
    {
        $posts = BoardMoa_Boards::get('posts');
        if (!$posts || !BoardMoa_Boards::listable($posts)) {
            return [];
        }
        return [['type' => 'documents', 'label' => BoardMoa_Text::t('작성글 보기'), 'mid' => $posts['mid'], 'search' => $this->memberSearch($posts, $userId)]];
    }

    public function canList($board)
    {
        if ($board['module'] === 'page') {
            $post = get_post((int)$board['ref']);
            return $post && in_array($post->post_type, self::PAGE_TYPES, true) && self::readable($post);
        }
        return true;
    }

    public function grant($board)
    {
        return [
            'list' => true,
            'view' => true,
            'write_document' => current_user_can('edit_posts') && ($board['ref'] ? current_user_can('assign_term', (int)$board['ref']) : true),
            'write_comment' => self::commentAllowed(),
            'manager' => current_user_can('edit_others_posts'),
        ];
    }

    /** 사이트 설정 '댓글을 달려면 로그인해야 함' */
    private static function commentAllowed()
    {
        return !get_option('comment_registration') || is_user_logged_in();
    }

    /** 웹에서 이 글을 볼 수 있는가: 공개, 비공개는 read_post, 그 밖(검토 대기·임시)은 고칠 수 있는 사람만(미리 보기) */
    public static function readable($post)
    {
        $status = get_post_status($post);
        if ($status === 'publish') {
            return true;
        }
        if ($status === 'private') {
            return current_user_can('read_post', $post->ID);
        }
        if (in_array($status, ['pending', 'draft', 'future'], true)) {
            return current_user_can('edit_post', $post->ID);
        }
        return false;
    }

    /**
     * 회원 등급·역할로 글을 가리는 플러그인이 이 사람에게 이 글을 막았는가 (웹은 본문 대신 안내 문구, 댓글은 숨김).
     * Members(내용 권한), Ultimate Member(글마다 제한), Paid Memberships Pro. 다른 플러그인은 boardmoa_post_restricted 필터.
     * 본문·요약은 플러그인 필터(the_content·get_the_excerpt)가 웹처럼 바꾸고, 여기서는 댓글·썸네일·댓글 쓰기를 막는다.
     */
    public static function restricted($post)
    {
        static $cache = [];
        $post = get_post($post);
        if (!$post) {
            return false;
        }
        $key = $post->ID . ':' . get_current_user_id();
        if (!isset($cache[$key])) {
            $r = false;
            if (function_exists('members_can_current_user_view_post') && (!function_exists('members_content_permissions_enabled') || members_content_permissions_enabled())) {
                $r = !members_can_current_user_view_post($post->ID);
            }
            if (!$r && function_exists('UM') && is_object(UM()->access()) && method_exists(UM()->access(), 'is_restricted')) {
                $r = (bool)UM()->access()->is_restricted($post->ID);
            }
            if (!$r && function_exists('pmpro_has_membership_access')) {
                $r = !pmpro_has_membership_access($post->ID);
            }
            $cache[$key] = (bool)apply_filters('boardmoa_post_restricted', $r, $post);
        }
        return $cache[$key];
    }

    /** 목록 요약: 웹 보관함의 요약처럼 get_the_excerpt 필터를 거친다(가리는 플러그인은 안내 문구로 바꾼다) */
    private static function excerpt($post, $text)
    {
        $saved = isset($GLOBALS['post']) ? $GLOBALS['post'] : null;
        $GLOBALS['post'] = $post;
        $filtered = apply_filters('get_the_excerpt', $text, $post);
        $GLOBALS['post'] = $saved;
        $filtered = BoardMoa_Html::summary((string)$filtered);
        return $filtered !== '' || self::restricted($post) ? $filtered : $text;
    }

    private static function inCategory($post, $catId)
    {
        foreach (wp_get_post_categories($post->ID) as $cat) {
            if ((int)$cat === (int)$catId || cat_is_ancestor_of((int)$catId, (int)$cat)) {
                return true;
            }
        }
        return false;
    }

    /** 이 글이 보이는 게시판: 첫 분류, 없으면 글 전체 */
    private function boardForPost($post)
    {
        $all = BoardMoa_Boards::all();
        foreach (wp_get_post_categories($post->ID) as $cat) {
            if (isset($all['cat-' . $cat])) {
                return $all['cat-' . $cat];
            }
        }
        return $all['posts'];
    }

    // ---- 목록

    private function categories($board)
    {
        $root = (int)$board['ref'];
        $terms = get_categories(['hide_empty' => false, 'child_of' => $root]);
        $out = [];
        foreach ($terms as $t) {
            $out[] = ['category_srl' => (int)$t->term_id, 'parent_srl' => (int)$t->parent === $root ? 0 : (int)$t->parent,
                'title' => BoardMoa_Html::text($t->name), 'document_count' => (int)$t->count, 'writable' => true];
        }
        return $out;
    }

    private function info($board, $grant)
    {
        $loggedIn = is_user_logged_in();
        $guestComment = null;
        if ($grant['write_comment'] && !$loggedIn) {
            $guestComment = get_option('require_name_email') ? ['nick_name', 'email_address'] : ['nick_name'];
        }
        // 댓글 양식의 CAPTCHA (CAPTCHA 4WP 등): 앱이 풀 수 있으면 미리 위젯
        $widget = $grant['write_comment'] ? BoardMoa_Captcha::widget('comment') : null;
        return $this->boardInfo($board, $grant, [
            'style' => 'webzine',
            'captcha' => ['document' => false, 'comment' => $widget !== null],
            'captcha_widget' => $widget,
            'categories' => $this->categories($board),
            'upload' => ['allowed' => $grant['write_document'] && current_user_can('upload_files'), 'max_file_size' => (int)wp_max_upload_size() ?: null, 'max_total_size' => null, 'files' => self::noFiles()],
            'write_url' => admin_url('post-new.php'),
            'guest_comment_fields' => $guestComment,
            // 워드프레스 댓글·글에는 비회원 비밀번호가 없다
            'guest_certify_fields' => null,
            // 댓글 단추 문구: 워드프레스 댓글 목록(comment_reply_link·edit_comment_link)과 같은 번역
            'labels' => ['comment_reply' => __('Reply'), 'comment_edit' => __('Edit')],
        ]);
    }

    private function query($board, $page, $perPage, $extra = [])
    {
        $args = array_merge([
            'post_type' => 'post', 'paged' => $page, 'posts_per_page' => $perPage, 'ignore_sticky_posts' => true,
            'no_found_rows' => false, 'suppress_filters' => false,
        ], $extra);
        $category = BoardMoa_Api::intParam('category');
        $root = (int)$board['ref'];
        if ($category && ($category === $root || !$root || cat_is_ancestor_of($root, $category))) {
            $args['cat'] = $category;
        } elseif ($root) {
            $args['cat'] = $root;
        }
        // 이름 메뉴의 '작성 글 보기' (member_srl): 그 회원의 글 (웹의 글쓴이 보관함 /author/… 과 같다)
        $member = BoardMoa_Api::intParam('member_srl');
        if ($member > 0) {
            $args['author'] = $member;
        }
        list($keyword, $target) = self::search();
        if ($keyword !== '') {
            if ($target === 'nick_name' || $target === 'user_id') {
                $users = get_users(['search' => '*' . $keyword . '*', 'search_columns' => $target === 'user_id' ? ['user_login'] : ['display_name', 'user_nicename'], 'fields' => 'ID', 'number' => 50]);
                $args['author__in'] = $users ? array_map('intval', $users) : [0];
            } else {
                $args['s'] = $keyword;
                if ($target === 'title') {
                    $args['search_columns'] = ['post_title'];
                } elseif ($target === 'content') {
                    $args['search_columns'] = ['post_content'];
                }
            }
        }
        return new WP_Query($args);
    }

    public function listPage($board)
    {
        $grant = $this->grant($board);
        list($page, $perPage) = self::pageArgs(get_option('posts_per_page', 10));
        $notices = [];
        $sticky = array_map('intval', (array)get_option('sticky_posts', []));
        $extra = [];
        // 글 전체(블로그 첫 화면)는 웹처럼 고정 글을 맨 위에
        if ($board['mid'] === 'posts' && $sticky && !BoardMoa_Api::intParam('category') && trim((string)BoardMoa_Api::param('search_keyword', '')) === '') {
            if ($page === 1) {
                $q = new WP_Query(['post_type' => 'post', 'post__in' => $sticky, 'posts_per_page' => count($sticky), 'ignore_sticky_posts' => true, 'orderby' => 'date']);
                foreach ($q->posts as $post) {
                    $notices[] = $this->summarize($post);
                }
            }
            $extra['post__not_in'] = $sticky;
        }
        $q = $this->query($board, $page, $perPage, $extra);
        $documents = [];
        foreach ($q->posts as $post) {
            $documents[] = $this->summarize($post);
        }
        return [
            'board' => $this->info($board, $grant),
            'notices' => $notices,
            'documents' => $documents,
            'page' => $page,
            'total_pages' => max(1, (int)$q->max_num_pages),
            'total_count' => (int)$q->found_posts,
        ];
    }

    public function recent($board, $limit)
    {
        $q = new WP_Query(['post_type' => 'post', 'posts_per_page' => $limit, 'ignore_sticky_posts' => true, 'no_found_rows' => true] + ($board['ref'] ? ['cat' => (int)$board['ref']] : []));
        $out = [];
        foreach ($q->posts as $post) {
            $out[] = ['time' => (int)get_post_time('U', true, $post), 'summary' => $this->summarize($post)];
        }
        return $out;
    }

    /** 비밀번호 글을 이번 요청에서 연 글 번호들 */
    private static $unlocked = [];

    private static function locked($post)
    {
        return $post->post_password !== '' && !isset(self::$unlocked[$post->ID]);
    }

    private function summarize($post)
    {
        $locked = self::locked($post);
        $uid = get_current_user_id();
        $cats = wp_get_post_categories($post->ID);
        $thumb = null;
        $summary = '';
        if (!$locked) {
            $restricted = self::restricted($post);
            $thumb = $restricted ? null : (get_the_post_thumbnail_url($post, 'medium_large') ?: BoardMoa_Html::firstImage($post->post_content));
            $summary = self::excerpt($post, $post->post_excerpt !== '' ? BoardMoa_Html::summary($post->post_excerpt) : BoardMoa_Html::summary($post->post_content));
        }
        return $this->summary([
            'document_srl' => (int)$post->ID,
            'title' => BoardMoa_Html::text(get_the_title($post)),
            'author' => BoardMoa_Html::text(get_the_author_meta('display_name', $post->post_author)),
            'author_image' => BoardMoa_Api::avatar($post->post_author),
            'author_srl' => (int)$post->post_author,
            'is_mine' => $uid && (int)$post->post_author === $uid,
            'regdate' => BoardMoa_Html::iso($post->post_date),
            'last_update' => BoardMoa_Html::iso($post->post_modified),
            'category_srl' => $cats ? (int)$cats[0] : 0,
            'comment_count' => (int)$post->comment_count,
            'is_notice' => is_sticky($post->ID),
            'is_secret' => $post->post_password !== '' || $post->post_status === 'private',
            'thumbnail' => $thumb ? BoardMoa_Html::absolute($thumb) : null,
            'summary' => $summary,
        ]);
    }

    // ---- 글

    /** 이 게시판의 읽을 수 있는 글. 비밀번호(password)를 보냈으면 맞는지 보고 이번 요청에서만 연다 */
    private function post($board, $srl)
    {
        $post = get_post((int)$srl);
        if (!$post || $post->post_type !== 'post' || ($board['ref'] && !self::inCategory($post, (int)$board['ref']))) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        if (!self::readable($post)) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        $password = BoardMoa_Api::param('password');
        if ($password === null || $password === '') {
            // 비밀번호로 연 글에 댓글 (기능 unlocked_comment): 앱은 연 비밀번호를 document_password 로 보낸다
            $password = BoardMoa_Api::param('document_password');
        }
        if ($post->post_password !== '' && $password !== null && $password !== '') {
            // 웹의 비밀번호 글 양식(wp-login.php?action=postpass)과 같은 비교: 저장된 글 비밀번호 그대로
            if (!hash_equals((string)$post->post_password, (string)$password)) {
                throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
            }
            self::$unlocked[$post->ID] = true;
            add_filter('post_password_required', function ($required, $p) {
                $p = get_post($p);
                return ($p && isset(self::$unlocked[$p->ID])) ? false : $required;
            }, PHP_INT_MAX, 2);
        }
        return $post;
    }

    public function document($board, $srl)
    {
        $post = $this->post($board, $srl);
        $grant = $this->grant($board);
        $summary = $this->summarize($post);
        $locked = self::locked($post);
        $html = null;
        $polls = null;
        if (!$locked) {
            // 새 앱(with_polls=1): 글 속 설문(WP-Polls) 자리를 앱 설문 카드로
            $withPolls = BoardMoa_Api::boolParam('with_polls') && BoardMoa_Polls::begin();
            $html = $this->render($post);
            // 글의 태그: 웹 글 화면 아래의 태그 목록처럼 본문 끝에 (가린 글은 빼고)
            if (!self::restricted($post)) {
                $tags = get_the_terms($post, 'post_tag');
                $html .= is_array($tags) ? self::tagsHtml(wp_list_pluck($tags, 'name')) : '';
            }
            if ($withPolls) {
                $polls = [];
                foreach (BoardMoa_Polls::end() as $pid => $resultOnly) {
                    if ($data = BoardMoa_Polls::data($pid, $resultOnly)) {
                        $polls[] = $data;
                    }
                }
            }
        }
        $restricted = self::restricted($post);
        return $this->detail($summary, [
            'content_html' => $html,
            'permanent_url' => get_permalink($post),
            'can_comment' => !$locked && !$restricted && $grant['write_comment'] && comments_open($post),
            // 비밀번호로 연 글: 댓글을 쓸 때 그 비밀번호를 document_password 로 같이 보낸다 (웹은 비밀번호 쿠키로 연다)
            'comment_document_password' => $post->post_password !== '' && isset(self::$unlocked[$post->ID]) && !$restricted && $grant['write_comment'] && comments_open($post),
            'can_edit' => current_user_can('edit_post', $post->ID),
            'can_delete' => current_user_can('delete_post', $post->ID),
            'password_view' => $locked,
            'board' => $this->info($board, $grant),
            'comments' => ($locked || $restricted) ? self::emptyComments() : $this->commentPage($post),
        ] + ($polls !== null || BoardMoa_Api::boolParam('with_polls') ? ['polls' => $polls ?: []] : []));
    }

    /** 글 속 설문에 투표 (POST poll.vote): 읽을 수 있는 글이고 그 본문에 든 설문이어야 한다 */
    public function pollVote($board, $srl)
    {
        if (!BoardMoa_Polls::available()) {
            throw new BoardMoa_Error(404, 'poll_not_found', '없는 설문입니다.');
        }
        $post = $this->post($board, $srl);
        if (self::locked($post) || self::restricted($post)) {
            throw BoardMoa_Api::denied();
        }
        BoardMoa_Polls::begin();
        $this->render($post);
        $ids = BoardMoa_Polls::end();
        return BoardMoa_Polls::vote($ids, BoardMoa_Api::intParam('poll_id'), BoardMoa_Api::param('choices', []));
    }

    /** 본문: 웹처럼 the_content (블록·숏코드·embed) */
    private function render($post)
    {
        $GLOBALS['post'] = $post;
        setup_postdata($post);
        $link = BoardMoa_Polls::beginLink(get_permalink($post));
        $html = apply_filters('the_content', get_the_content(null, false, $post));
        if ($link) {
            BoardMoa_Polls::endLink();
        }
        wp_reset_postdata();
        return BoardMoa_Html::content(BoardMoa_Html::webOnlyForms(str_replace(']]>', ']]&gt;', $html), get_permalink($post)));
    }

    public function comments($board, $srl)
    {
        $post = $this->post($board, $srl);
        if (self::locked($post)) {
            throw new BoardMoa_Error(403, 'not_permitted', '비밀번호를 넣어야 볼 수 있는 글입니다.');
        }
        if (self::restricted($post)) {
            return self::emptyComments();
        }
        return $this->commentPage($post);
    }

    /** 댓글: 웹 댓글 목록(comments_template)과 같은 기준 — 승인된 것 + 내가 쓴 승인 대기, 사이트의 묶음 깊이·순서 */
    private function commentPage($post)
    {
        $uid = get_current_user_id();
        $args = ['post_id' => $post->ID, 'status' => 'approve', 'orderby' => 'comment_date_gmt', 'order' => 'ASC', 'type__not_in' => ['note']];
        if ($uid) {
            $args['include_unapproved'] = [$uid];
        }
        $all = get_comments($args);
        // 웹 댓글 목록(comments_template)과 같은 거르기 (회원 등급 플러그인 등)
        $saved = isset($GLOBALS['post']) ? $GLOBALS['post'] : null;
        $GLOBALS['post'] = $post;
        $all = (array)apply_filters('comments_array', $all, $post->ID);
        $GLOBALS['post'] = $saved;
        $threaded = (bool)get_option('thread_comments');
        $maxDepth = $threaded ? max(1, (int)get_option('thread_comments_depth', 5)) : 1;
        $children = [];
        $byId = [];
        foreach ($all as $c) {
            $byId[(int)$c->comment_ID] = $c;
        }
        $top = [];
        foreach ($all as $c) {
            $parent = (int)$c->comment_parent;
            if ($threaded && $parent && isset($byId[$parent])) {
                $children[$parent][] = $c;
            } else {
                $top[] = $c;
            }
        }
        if (get_option('comment_order') === 'desc') {
            $top = array_reverse($top);
        }
        $flat = [];
        $walk = function ($list, $depth, $parentId) use (&$walk, &$flat, $children, $maxDepth) {
            foreach ($list as $c) {
                $flat[] = [$c, min($depth, $maxDepth - 1), $parentId];
                if (isset($children[(int)$c->comment_ID])) {
                    $walk($children[(int)$c->comment_ID], $depth + 1, (int)$c->comment_ID);
                }
            }
        };
        $walk($top, 0, 0);
        $perPage = 100;
        $page = max(1, BoardMoa_Api::intParam('cpage', 1));
        $total = count($flat);
        $items = [];
        foreach (array_slice($flat, ($page - 1) * $perPage, $perPage) as $row) {
            list($c, $depth, $parentId) = $row;
            $items[] = $this->commentOut($c, $depth, $parentId);
        }
        return ['items' => $items, 'page' => $page, 'total_pages' => max(1, (int)ceil($total / $perPage)), 'total_count' => $total];
    }

    private function commentOut($c, $depth, $parentId)
    {
        $uid = get_current_user_id();
        $userId = (int)$c->user_id;
        $text = apply_filters('comment_text', get_comment_text($c), $c, []);
        if ((string)$c->comment_approved !== '1') {
            $text = '<p><em>' . esc_html(BoardMoa_Text::t('승인을 기다리는 댓글입니다.')) . '</em></p>' . $text;
        }
        $canEdit = current_user_can('edit_comment', $c->comment_ID);
        return $this->commentItem([
            'comment_srl' => (int)$c->comment_ID,
            'parent_srl' => (int)$parentId,
            'depth' => (int)$depth,
            'author' => BoardMoa_Html::text(get_comment_author($c)),
            'author_image' => $userId ? BoardMoa_Api::avatar($userId) : null,
            'author_srl' => $userId,
            // 웹: 댓글 이름은 글쓴이 보관함이 아니라, 웹사이트 주소가 있을 때만 그 주소로 (get_comment_author_link)
            'author_menu' => false,
            'author_url' => wp_http_validate_url((string)$c->comment_author_url) ? esc_url_raw((string)$c->comment_author_url) : null,
            'is_mine' => $uid && $userId === $uid,
            'regdate' => BoardMoa_Html::iso($c->comment_date),
            'content_html' => BoardMoa_Html::content($text),
            'can_edit' => $canEdit,
            'can_delete' => $canEdit,
            'vote' => self::wpdiscuzVote($c),
        ]);
    }

    // ---- 댓글 추천: wpDiscuz 가 켜져 있고 웹 댓글에 추천 단추를 보일 때 (기능 comment_vote)

    /** wpDiscuz 가 이 글의 댓글을 맡고 추천 단추를 보이는가 */
    private static function wpdiscuzOn($post)
    {
        if (!function_exists('wpDiscuz') || !class_exists('WpdiscuzCore')) {
            return false;
        }
        $wpd = wpDiscuz();
        if (!is_object($wpd) || !isset($wpd->options->thread_layouts['showVotingButtons']) || !$wpd->options->thread_layouts['showVotingButtons']) {
            return false;
        }
        if (!$post) {
            return true;
        }
        // 웹 글 화면에서 wpDiscuz 가 댓글을 맡는가 (isLoadWpdiscuz 와 같은 조건, 글 화면이 아닌 요청에서도 되는 isPostSupportedByWpdiscuz 로)
        $post = get_post($post);
        if (!$post || !(comments_open($post) || $post->comment_count)) {
            return false;
        }
        if (isset($wpd->helper) && method_exists($wpd->helper, 'isPostSupportedByWpdiscuz')) {
            return (bool)$wpd->helper->isPostSupportedByWpdiscuz($post->ID);
        }
        return isset($wpd->wpdiscuzForm) && (bool)$wpd->wpdiscuzForm->getForm($post->ID)->getFormID() && post_type_supports($post->post_type, 'comments');
    }

    /** 기능 목록에 comment_vote 를 넣을지 */
    public static function wpdiscuzVoting()
    {
        return self::wpdiscuzOn(null);
    }

    /** wpDiscuz 댓글 추천 상태 (웹 댓글 아래 단추와 같은 값). 쓰지 않으면 null */
    private static function wpdiscuzVote($c)
    {
        if ((string)$c->comment_approved !== '1' || !self::wpdiscuzOn((int)$c->comment_post_ID)) {
            return null;
        }
        $wpd = wpDiscuz();
        $layout = $wpd->options->thread_layouts;
        // 웹 댓글 목록(WpdiscuzWalker)과 같은 판단: wpdiscuz_show_vote 가 끄면 추천 칸이 없고,
        // 이 사람이 누를 수 없는 단추(자기 댓글·비회원 추천 불가·같은 IP 비회원)는 wpdiscuz_hide_readonly_vote_buttons 가 참이면 감춘다(기본은 흐리게 보임)
        $current = wp_get_current_user();
        $author = '';
        if ((int)$c->user_id) {
            $author = get_user_by('id', (int)$c->user_id);
        } elseif (!empty($wpd->options->login['isUserByEmail'])) {
            $author = get_user_by('email', (string)$c->comment_author_email);
        }
        if (!(bool)apply_filters('wpdiscuz_show_vote', true, $c, $author, $current)) {
            return null;
        }
        $uid = (int)$current->ID;
        if ($uid) {
            $denial = $uid === (int)$c->user_id ? 'self_vote' : '';
        } else {
            $ip = class_exists('WpdiscuzHelper') && method_exists('WpdiscuzHelper', 'getRealIPAddr') ? (string)WpdiscuzHelper::getRealIPAddr() : '';
            if (empty($layout['isGuestCanVote']) || trim($ip) === '') {
                $denial = 'login_required';
            } else {
                $denial = method_exists('WpdiscuzHelper', 'shouldDenyGuestVoteFromSameIP') && WpdiscuzHelper::shouldDenyGuestVoteFromSameIP($c, $ip) ? 'same_ip' : '';
            }
        }
        if ($denial !== '' && (bool)apply_filters('wpdiscuz_hide_readonly_vote_buttons', false, $c, $denial)) {
            return null;
        }
        $dislike = !empty($layout['enableDislikeButton']);
        $my = 0;
        $who = $uid ?: (class_exists('WpdiscuzHelper') && method_exists('WpdiscuzHelper', 'getGuestIdentity') ? WpdiscuzHelper::getGuestIdentity((string)WpdiscuzHelper::getRealIPAddr()) : false);
        if ($who && isset($wpd->dbManager) && method_exists($wpd->dbManager, 'isUserVoted')) {
            $v = (int)$wpd->dbManager->isUserVoted($who, (int)$c->comment_ID);
            $my = $v > 0 ? 1 : ($v < 0 ? -1 : 0);
        }
        // 웹 단추의 수: 따로(좋아요·싫어요) 또는 합계 하나
        if (!empty($layout['votingButtonsStyle'])) {
            $sep = get_comment_meta((int)$c->comment_ID, 'wpdiscuz_votes_seperate', true);
            $up = is_array($sep) && isset($sep['like']) ? (int)$sep['like'] : 0;
            $down = is_array($sep) && isset($sep['dislike']) ? abs((int)$sep['dislike']) : 0;
        } else {
            $up = (int)get_comment_meta((int)$c->comment_ID, 'wpdiscuz_votes', true);
            $down = 0;
        }
        return [
            // 자기 댓글·같은 IP 비회원: 웹은 흐린 단추로 보인다 → 보이되 못 누름(shown, 1.1.20~). 비회원 추천 불가는 누르면 로그인을 묻는다(앱도 같게)
            'up' => ['enabled' => !in_array($denial, ['self_vote', 'same_ip'], true), 'count' => $up, 'shown' => true],
            'down' => ['enabled' => $dislike && !in_array($denial, ['self_vote', 'same_ip'], true), 'count' => $down, 'shown' => $dislike],
            'my_vote' => $my,
            // wpDiscuz 는 누른 것을 반대 단추(싫어요가 없으면 같은 단추)로 되돌린다
            'can_cancel' => true,
        ];
    }

    /** 댓글 추천: 웹 단추의 wpDiscuz 처리(WpdiscuzHelperAjax::voteOnComment — 비회원 허용·자기 댓글·한 번만·속도 제한)와 같은 판단 */
    public function commentVote($board, $commentSrl)
    {
        $c = get_comment((int)$commentSrl);
        if (!$c || (string)$c->comment_approved !== '1') {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        $post = $this->post($board, (int)$c->comment_post_ID);
        if (self::locked($post) || self::restricted($post)) {
            throw BoardMoa_Api::denied();
        }
        $vote = self::wpdiscuzVote($c);
        if (!$vote) {
            throw new BoardMoa_Error(403, 'not_permitted', '이 게시판은 추천을 쓰지 않습니다.');
        }
        $wpd = wpDiscuz();
        if (!is_user_logged_in() && empty($wpd->options->thread_layouts['isGuestCanVote'])) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        $point = BoardMoa_Api::intParam('point', 1) < 0 ? -1 : 1;
        if (BoardMoa_Api::boolParam('cancel')) {
            if (!$vote['my_vote']) {
                return $vote;
            }
            // 되돌리기: 싫어요가 있으면 반대 값, 없으면 같은 단추를 다시 (웹과 같다)
            $point = $vote['down']['enabled'] ? -$vote['my_vote'] : 1;
        } elseif ($point < 0 && !$vote['down']['enabled']) {
            throw new BoardMoa_Error(403, 'not_permitted', '이 게시판은 추천을 쓰지 않습니다.');
        }
        // wpDiscuz 의 처리기는 값을 filter_input(INPUT_POST) 로 읽어 앱 요청(JSON 본문)에서는 부를 수 없다.
        // 처리기(WpdiscuzHelperAjax::voteOnComment)와 같은 차례·같은 wpDiscuz 함수로 처리한다 (속도 제한·차단·비회원·글 접근·자기 댓글·같은 IP·한 번만, 훅·캐시 비우기)
        $helper = $wpd->helper;
        $fail = function ($code) use ($wpd) {
            if ($code === 'wc_login_to_vote') {
                return new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            $text = method_exists($wpd->options, 'getPhrase') ? trim((string)$wpd->options->getPhrase($code)) : '';
            return new BoardMoa_Error(400, 'vote_failed', $text !== '' && $text !== $code ? BoardMoa_Html::text($text) : '추천하지 못했습니다.', $text !== '' && $text !== $code);
        };
        if (method_exists($helper, 'checkRateLimit') && is_wp_error($limit = $helper->checkRateLimit('vote', 20, MINUTE_IN_SECONDS))) {
            throw $fail($limit->get_error_code());
        }
        if (method_exists($helper, 'isBanned') && $helper->isBanned()) {
            throw $fail('wc_banned_user');
        }
        if (method_exists('WpdiscuzHelper', 'canCurrentUserAccessPost') && !WpdiscuzHelper::canCurrentUserAccessPost($post)) {
            throw $fail('wc_msg_post_not_found');
        }
        $userIP = (string)WpdiscuzHelper::getRealIPAddr();
        $userID = get_current_user_id();
        $guest = WpdiscuzHelper::getGuestIdentity($userIP);
        if ($userID && $userID === (int)$c->user_id) {
            throw $fail('wc_self_vote');
        }
        if (!$userID && $guest === false) {
            throw $fail('wc_login_to_vote');
        }
        if (!$userID && method_exists('WpdiscuzHelper', 'shouldDenyGuestVoteFromSameIP') && WpdiscuzHelper::shouldDenyGuestVoteFromSameIP($c, $userIP)) {
            throw $fail('wc_deny_voting_from_same_ip');
        }
        $who = $userID ?: $guest;
        $commentId = (int)$c->comment_ID;
        $dislike = (bool)$vote['down']['enabled'];
        $voteType = $point;
        $before = $wpd->dbManager->isUserVoted($who, $commentId);
        $separate = get_comment_meta($commentId, 'wpdiscuz_votes_seperate', true);
        $separate = is_array($separate) ? $separate : ['like' => 0, 'dislike' => 0];
        if ($before !== null && $before !== '') {
            $was = (int)$before;
            $new = $was + $voteType;
            if (!(($new >= -1 && $new <= 1) || ($new == 2 && !$dislike))) {
                throw $fail('wc_vote_only_one_time');
            }
            if ($new == 2) {
                $new = 0;
                $voteType = -1;
            }
            $wpd->dbManager->updateVoteType($who, $commentId, $new, current_time('timestamp'));
            update_comment_meta($commentId, 'wpdiscuz_votes', '' . ((int)get_comment_meta($commentId, 'wpdiscuz_votes', true) + $voteType));
            if ($new == 0) {
                if ($was == 1) {
                    $separate['like'] -= 1;
                } elseif ($was == -1) {
                    $separate['dislike'] -= 1;
                }
            } elseif ($voteType == 1) {
                $separate['like'] += 1;
            } else {
                $separate['dislike'] += 1;
            }
            update_comment_meta($commentId, 'wpdiscuz_votes_seperate', $separate);
            do_action('wpdiscuz_update_vote', $voteType, $before, $c);
        } else {
            $wpd->dbManager->addVoteType($who, $commentId, $voteType, (int)is_user_logged_in(), (int)$c->comment_post_ID, current_time('timestamp'));
            update_comment_meta($commentId, 'wpdiscuz_votes', '' . ((int)get_comment_meta($commentId, 'wpdiscuz_votes', true) + $voteType));
            if ($voteType == 1) {
                $separate['like'] += 1;
            } else {
                $separate['dislike'] += 1;
            }
            update_comment_meta($commentId, 'wpdiscuz_votes_seperate', $separate);
            do_action('wpdiscuz_add_vote', $voteType, $c);
        }
        if (!empty($wpd->options->thread_display['mostVotedByDefault'])) {
            do_action('wpdiscuz_reset_comments_cache', (int)$c->comment_post_ID);
        } else {
            do_action('wpdiscuz_reset_comments_extra_cache', (int)$c->comment_post_ID);
        }
        do_action('wpdiscuz_clean_post_cache', (int)$c->comment_post_ID, 'comment_voted');
        clean_comment_cache($commentId);
        return self::wpdiscuzVote(get_comment($commentId));
    }

    public function boardOfDocument($srl)
    {
        $post = get_post((int)$srl);
        return ($post && $post->post_type === 'post') ? $this->boardForPost($post) : null;
    }

    public function locate($url)
    {
        $home = home_url('/');
        $path = (string)parse_url($url, PHP_URL_PATH);
        parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
        $homePath = (string)parse_url($home, PHP_URL_PATH);
        if (rtrim($path, '/') === rtrim($homePath, '/') && !$query) {
            return ['mid' => BoardMoa_Boards::homeMid()];
        }
        // 분류 보관함 /category/<슬러그>/
        $base = trim((string)get_option('category_base'), '/') ?: 'category';
        $rel = substr(rawurldecode($path), strlen(rtrim($homePath, '/')));
        if (preg_match('#^/' . preg_quote($base, '#') . '/(.+?)/?$#u', $rel, $m)) {
            $term = get_category_by_path($m[1], true);
            if ($term) {
                return ['mid' => 'cat-' . $term->term_id];
            }
        }
        // 글쓴이 보관함 /author/<이름>/ 또는 ?author=<번호>: 웹처럼 그 글쓴이의 글 전체 (앱은 '작성글' 화면, 1.1.0~)
        global $wp_rewrite;
        $authorBase = trim((string)($wp_rewrite->author_base ?? 'author'), '/') ?: 'author';
        $author = null;
        if (preg_match('#^/' . preg_quote($authorBase, '#') . '/([^/]+)/?$#u', $rel, $m)) {
            $author = get_user_by('slug', $m[1]);
        } elseif (!empty($query['author']) && is_numeric($query['author'])) {
            $author = get_user_by('id', (int)$query['author']);
        }
        if ($author) {
            $posts = BoardMoa_Boards::get('posts');
            return $posts ? ['mid' => 'posts', 'author' => BoardMoa_Html::text($author->display_name),
                'search' => $this->memberSearch($posts, (int)$author->ID)] : null;
        }
        if (!empty($query['cat']) && is_numeric($query['cat'])) {
            return ['mid' => 'cat-' . (int)$query['cat']];
        }
        // 글 목록 페이지(설정 > 읽기의 '글 페이지')는 url_to_postid 가 0 을 준다 → 주소를 직접 견준다
        $postsPage = self::postsPage();
        if ($postsPage && rtrim(rawurldecode($path), '/') === rtrim(rawurldecode((string)parse_url(get_permalink($postsPage), PHP_URL_PATH)), '/')) {
            return ['mid' => 'posts'];
        }
        $id = url_to_postid($url);
        // 한글 등 슬러그 페이지를 url_to_postid 가 못 찾으면 경로로
        if (!$id && $rel !== '' && $rel !== '/' && !$query) {
            $page = get_page_by_path(trim($rel, '/'));
            $id = $page ? (int)$page->ID : 0;
        }
        if (!$id && !empty($query['p'])) {
            $id = (int)$query['p'];
        }
        if (!$id && !empty($query['page_id'])) {
            $id = (int)$query['page_id'];
        }
        $post = $id ? get_post($id) : null;
        if (!$post) {
            return null;
        }
        if ($post->post_type === 'post') {
            $board = $this->boardForPost($post);
            return ['mid' => $board['mid'], 'document_srl' => (int)$post->ID];
        }
        if ($post->post_type === 'page') {
            if ((int)$post->ID === self::postsPage()) {
                return ['mid' => 'posts'];
            }
            $target = BoardMoa_Boards::targetOfPost($post);
            return $target && $target['mid'] ? ['mid' => $target['mid']] : ['mid' => 'page-' . $post->ID];
        }
        return null;
    }

    // ---- 페이지

    public function page($board)
    {
        $post = get_post((int)$board['ref']);
        if (!$post || !in_array($post->post_type, self::PAGE_TYPES, true) || !self::readable($post)) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        // 비밀번호 페이지, 회원 등급 플러그인(Members·Ultimate Member·PMPro)이 이 사람에게 가린 페이지는 웹에서 연다
        // (웹은 안내 문구를 보이거나 다른 곳으로 보낸다 — 플러그인 설정마다 달라 앱에서는 본문을 주지 않는다)
        $locked = $post->post_password !== '' || self::restricted($post);
        return [
            'mid' => $board['mid'],
            'title' => BoardMoa_Html::text(get_the_title($post)),
            'page_type' => $locked ? 'outside' : 'article',
            'content_html' => $locked ? '' : $this->render($post),
            'web_url' => get_permalink($post),
        ];
    }

    // ---- 쓰기

    private function chosenCategory($board)
    {
        $category = BoardMoa_Api::intParam('category_srl');
        $root = (int)$board['ref'];
        if ($category && ($category === $root || !$root || cat_is_ancestor_of($root, $category)) && term_exists($category, 'category')) {
            return $category;
        }
        return $root ?: 0;
    }

    /** 사진을 미디어 보관함에 올려(웹의 '미디어 추가'와 같은 media_handle_upload) 글에 붙이고, 본문에 넣을 HTML */
    private function uploadPhotos($postId, array $photos)
    {
        if (!current_user_can('upload_files')) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $style = self::photoStyle();
        $html = '';
        foreach ($photos as $i => $file) {
            $_FILES['boardmoa_photo'] = $file;
            $id = media_handle_upload('boardmoa_photo', $postId);
            unset($_FILES['boardmoa_photo']);
            if (is_wp_error($id)) {
                throw new BoardMoa_Error(400, 'upload_failed', $id->get_error_message(), true);
            }
            $url = wp_get_attachment_image_url($id, 'large') ?: wp_get_attachment_url($id);
            $html .= "\n<figure class=\"wp-block-image\"><img src=\"" . esc_url($url) . '" alt="" class="wp-image-' . (int)$id . '" style="' . esc_attr($style) . '"/></figure>';
        }
        return $html;
    }

    public function write($board)
    {
        $grant = $this->grant($board);
        if (!is_user_logged_in()) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!$grant['write_document']) {
            throw BoardMoa_Api::denied();
        }
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $content = BoardMoa_Html::contentParam();
        $photos = self::photos();
        if (self::attachments()) {
            // 워드프레스 글쓰기에는 파일 첨부 칸이 없다 (기능 file_upload: upload.files.allowed false)
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 파일을 올릴 수 없습니다.');
        }
        if ($title === '' || ($content === '' && !$photos)) {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        if ($photos && !current_user_can('upload_files')) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        $category = $this->chosenCategory($board);
        $id = wp_insert_post(wp_slash([
            'post_title' => mb_substr($title, 0, 200),
            'post_content' => $content,
            'post_status' => current_user_can('publish_posts') ? 'publish' : 'pending',
            'post_author' => get_current_user_id(),
            'post_type' => 'post',
            'post_category' => $category ? [$category] : [],
        ]), true);
        if (is_wp_error($id)) {
            throw new BoardMoa_Error(400, 'write_failed', $id->get_error_message(), true);
        }
        if ($photos) {
            $html = $this->uploadPhotos($id, $photos);
            wp_update_post(wp_slash(['ID' => $id, 'post_content' => $content . $html]));
        }
        return ['document_srl' => (int)$id];
    }

    private function editablePost($board, $srl, $cap)
    {
        $post = get_post((int)$srl);
        if (!$post || $post->post_type !== 'post' || ($board['ref'] && !self::inCategory($post, (int)$board['ref'])) || !self::readable($post)) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        if (!current_user_can($cap, $post->ID)) {
            throw BoardMoa_Api::denied();
        }
        return $post;
    }

    public function source($board, $srl)
    {
        $post = $this->editablePost($board, $srl, 'edit_post');
        $grant = $this->grant($board);
        $cats = wp_get_post_categories($post->ID);
        return [
            'document_srl' => (int)$post->ID,
            'title' => (string)$post->post_title,
            'content' => (string)$post->post_content,
            'base_url' => trailingslashit(home_url('/')),
            'manage' => null,
            'category_srl' => $cats ? (int)$cats[0] : 0,
            'extra_keys' => [],
            'extra_values' => (object)[],
            'board' => $this->info($board, $grant),
            'upload' => ['allowed' => current_user_can('upload_files'), 'max_file_size' => (int)wp_max_upload_size() ?: null, 'max_total_size' => null, 'files' => self::noFiles()],
        ];
    }

    public function update($board, $srl)
    {
        $post = $this->editablePost($board, $srl, 'edit_post');
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $content = (string)BoardMoa_Api::param('content', '');
        $photos = self::photos();
        if (self::attachments()) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', '이 게시판에는 파일을 올릴 수 없습니다.');
        }
        if ($title === '' || (trim(wp_strip_all_tags($content, true)) === '' && strpos($content, '<img') === false && !$photos)) {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        if ($photos) {
            $content .= $this->uploadPhotos($post->ID, $photos);
        }
        $data = ['ID' => $post->ID, 'post_title' => mb_substr($title, 0, 200), 'post_content' => $content];
        if (BoardMoa_Api::param('category_srl') !== null && ($category = $this->chosenCategory($board))) {
            $data['post_category'] = [$category];
        }
        $result = wp_update_post(wp_slash($data), true);
        if (is_wp_error($result)) {
            throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
        }
        return ['document_srl' => (int)$post->ID];
    }

    public function delete($board, $srl)
    {
        $post = $this->editablePost($board, $srl, 'delete_post');
        // 웹(관리 화면)의 '휴지통으로'
        if (!wp_trash_post($post->ID)) {
            throw new BoardMoa_Error(400, 'delete_failed', '지우지 못했습니다.');
        }
        return ['deleted' => true];
    }

    public function commentWrite($board, $srl)
    {
        $post = $this->post($board, $srl);
        if (self::locked($post)) {
            throw new BoardMoa_Error(403, 'not_permitted', '비밀번호를 넣어야 볼 수 있는 글입니다.');
        }
        if (self::restricted($post)) {
            throw BoardMoa_Api::denied();
        }
        $content = trim(str_replace(["\r\n", "\r"], "\n", (string)BoardMoa_Api::param('content', '')));
        $parent = BoardMoa_Api::intParam('parent_srl');
        if (!is_user_logged_in() && get_option('comment_registration')) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!is_user_logged_in() && BoardMoa_Api::param('nick_name') === null && BoardMoa_Api::param('email_address') === null) {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        BoardMoa_Captcha::check('comment');
        // wp-comments-post.php 와 같은 처리 (댓글 닫힘·이름과 메일·도배·중복·승인 설정·스팸 플러그인)
        $run = BoardMoa_Run::call(function () use ($post, $content, $parent) {
            return wp_handle_comment_submission(wp_slash([
                'comment_post_ID' => $post->ID,
                'comment' => $content,
                'comment_parent' => $parent,
                'author' => (string)BoardMoa_Api::param('nick_name', ''),
                'email' => (string)BoardMoa_Api::param('email_address', ''),
                'url' => '',
            ]));
        }, 'comment_failed', 400);
        if ($run['died'] !== null) {
            throw new BoardMoa_Error(400, 'comment_failed', $run['died'], true);
        }
        $comment = $run['value'];
        if (is_wp_error($comment)) {
            $code = $comment->get_error_code();
            if ($code === 'not_logged_in') {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            if (BoardMoa_Captcha::isError($comment)) {
                throw BoardMoa_Captcha::error('comment', BoardMoa_Captcha::widget('comment') ? null : BoardMoa_Html::text($comment->get_error_message()));
            }
            if ($code === 'require_name_email' || $code === 'require_valid_email') {
                throw new BoardMoa_Error(400, 'guest_info_required', BoardMoa_Html::text($comment->get_error_message()), true);
            }
            throw new BoardMoa_Error($code === 'comment_closed' ? 403 : 400, 'comment_failed', BoardMoa_Html::text($comment->get_error_message()), true);
        }
        if (!$comment instanceof WP_Comment) {
            throw new BoardMoa_Error(400, 'comment_failed', '댓글을 쓰지 못했습니다.');
        }
        return ['comment_srl' => (int)$comment->comment_ID, 'document_srl' => (int)$post->ID, 'pending' => (string)$comment->comment_approved !== '1'];
    }

    private function editableComment($board, $commentSrl)
    {
        $c = get_comment((int)$commentSrl);
        if (!$c) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 댓글입니다.');
        }
        $this->post($board, (int)$c->comment_post_ID);
        if (!current_user_can('edit_comment', $c->comment_ID)) {
            throw BoardMoa_Api::denied();
        }
        return $c;
    }

    public function commentUpdate($board, $commentSrl)
    {
        $c = $this->editableComment($board, $commentSrl);
        $content = trim((string)BoardMoa_Api::param('content', ''));
        if ($content === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $result = wp_update_comment(wp_slash(['comment_ID' => (int)$c->comment_ID, 'comment_content' => $content]), true);
        if (is_wp_error($result)) {
            throw new BoardMoa_Error(400, 'update_failed', $result->get_error_message(), true);
        }
        return ['comment_srl' => (int)$c->comment_ID, 'document_srl' => (int)$c->comment_post_ID];
    }

    public function commentDelete($board, $commentSrl)
    {
        $c = $this->editableComment($board, $commentSrl);
        if (!wp_trash_comment($c->comment_ID)) {
            throw new BoardMoa_Error(400, 'delete_failed', '지우지 못했습니다.');
        }
        return ['deleted' => true];
    }

    // ---- 내 활동

    public function myDocuments($limit)
    {
        $q = new WP_Query(['post_type' => 'post', 'author' => get_current_user_id(), 'post_status' => ['publish', 'private', 'pending', 'future'],
            'posts_per_page' => $limit, 'ignore_sticky_posts' => true, 'no_found_rows' => true]);
        $out = [];
        foreach ($q->posts as $post) {
            $board = $this->boardForPost($post);
            $s = $this->summarize($post);
            $s['mid'] = $board['mid'];
            $s['board_title'] = $board['title'];
            $out[] = ['time' => (int)get_post_time('U', true, $post), 'summary' => $s];
        }
        return $out;
    }

    public function myComments($limit)
    {
        $out = [];
        foreach (get_comments(['user_id' => get_current_user_id(), 'number' => $limit, 'status' => 'all', 'type__not_in' => ['note'], 'post_type' => 'post']) as $c) {
            $post = get_post($c->comment_post_ID);
            if (!$post || !self::readable($post) || self::restricted($post)) {
                continue;
            }
            $board = $this->boardForPost($post);
            $out[] = ['time' => strtotime($c->comment_date_gmt . ' UTC'), 'comment' => [
                'comment_srl' => (int)$c->comment_ID, 'document_srl' => (int)$post->ID, 'content' => BoardMoa_Html::summary($c->comment_content, 200),
                'regdate' => BoardMoa_Html::iso($c->comment_date), 'is_secret' => false, 'document_title' => BoardMoa_Html::text(get_the_title($post)),
                'mid' => $board['mid'], 'board_title' => $board['title'],
            ]];
        }
        return $out;
    }
}
